// تست ساده برای توابع کمکی (بدون نیاز به پلاگین‌های نیتیو)
import 'package:flutter_test/flutter_test.dart';
import 'package:not_app/models/episode.dart';

void main() {
  test('formatDuration', () {
    expect(formatDuration(const Duration(minutes: 3, seconds: 5)), '03:05');
    expect(formatDuration(const Duration(hours: 1, minutes: 2, seconds: 3)), '1:02:03');
  });

  test('Episode json round-trip', () {
    const e = Episode(
      id: 'a', podcastId: 'p', podcastTitle: 't', title: 'x',
      audioUrl: 'u', imageUrl: 'i', duration: Duration(seconds: 90),
    );
    final back = Episode.fromJson(e.toJson());
    expect(back.id, 'a');
    expect(back.duration.inSeconds, 90);
  });
}
