// ─────────────────────────────────────────────
// lib/widgets/episode_tile.dart
// ردیف اپیزود: عنوان، تاریخ (timeago)، مدت، دانلود، قلب
// playEpisodeWithFeedback: پخش + نمایش خطا در SnackBar
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../models/episode.dart';
import '../providers/favorites_provider.dart';
import '../providers/player_provider.dart';
import '../services/download_service.dart';
import '../theme/app_theme.dart';
import 'podcast_card.dart';

Future<void> playEpisodeWithFeedback(
    BuildContext context, Episode e, List<Episode> queue) async {
  final err = await context.read<PlayerProvider>().playEpisode(e, queue: queue);
  if (err != null && context.mounted) showAppSnack(context, err);
}

class EpisodeTile extends StatelessWidget {
  final Episode episode;
  final List<Episode> queue;

  const EpisodeTile({super.key, required this.episode, required this.queue});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final favs = context.watch<FavoritesProvider>();
    final cs = Theme.of(context).colorScheme;
    final isCurrent = player.episode?.id == episode.id;

    final subtitleParts = <String>[
      if (episode.pubDate != null)
        timeago.format(episode.pubDate!, locale: 'fa'),
      if (episode.duration > Duration.zero) formatDuration(episode.duration),
    ];

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: PodcastImage(url: episode.imageUrl, size: 52, radius: 10),
      title: Text(
        episode.title,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          color: isCurrent ? cs.primary : null,
        ),
      ),
      subtitle: subtitleParts.isEmpty ? null : Text(subtitleParts.join(' • ')),
      onTap: () => playEpisodeWithFeedback(context, episode, queue),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (isCurrent && player.isPlaying)
            Icon(Icons.graphic_eq, color: cs.primary),
          IconButton(
            tooltip: 'دانلود',
            icon: const Icon(Icons.download_outlined),
            onPressed: () async {
              final ok = await DownloadService.instance.download(episode);
              if (!ok && context.mounted) {
                showAppSnack(context, 'دانلود به‌زودی فعال می‌شود');
              }
            },
          ),
          IconButton(
            tooltip: 'علاقه‌مندی',
            icon: Icon(
              favs.isFavorite(episode.id) ? Icons.favorite : Icons.favorite_border,
              color: favs.isFavorite(episode.id) ? Colors.red : null,
            ),
            onPressed: () => favs.toggleFavorite(episode),
          ),
        ],
      ),
    );
  }
}
