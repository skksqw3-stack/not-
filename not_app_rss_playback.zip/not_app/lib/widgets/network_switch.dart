// ─────────────────────────────────────────────
// lib/widgets/network_switch.dart
// NetworkSwitch: کلید روشن/خاموش اینترنت برنامه (حالت کامل و فشرده)
// OfflineBanner: نوار قرمز هشدار هنگام قطع بودن اینترنت
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../services/network_guard.dart';
import '../theme/app_theme.dart';

class NetworkSwitch extends StatelessWidget {
  /// compact = true برای AppBar (آیکون + Switch کوچک)
  final bool compact;
  const NetworkSwitch({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final g = NetworkGuard.instance;
    return StreamBuilder<bool>(
      stream: g.statusStream,
      initialData: g.isOnline,
      builder: (context, _) {
        final online = g.isOnline;
        final color = online ? Colors.green : Colors.red;

        void change(bool v) {
          g.setUserEnabled(v);
          showAppSnack(context,
              v ? 'اینترنت برنامه روشن شد' : 'اینترنت برنامه قطع شد');
        }

        if (compact) {
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(online ? Icons.wifi : Icons.wifi_off, color: color),
              Switch(
                value: g.userEnabled,
                activeColor: Colors.green,
                inactiveThumbColor: Colors.red,
                onChanged: change,
              ),
            ],
          );
        }

        final subtitle = !g.deviceConnected
            ? 'گوشی به اینترنت وصل نیست'
            : (!g.userEnabled ? 'شما قطع کردید' : 'فعال');

        return SwitchListTile(
          secondary: Icon(online ? Icons.wifi : Icons.wifi_off, color: color),
          title: const Text('اینترنت برنامه'),
          subtitle: Text(subtitle, style: TextStyle(color: color)),
          value: g.userEnabled,
          activeColor: Colors.green,
          onChanged: change,
        );
      },
    );
  }
}

class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final g = NetworkGuard.instance;
    return StreamBuilder<bool>(
      stream: g.statusStream,
      initialData: g.isOnline,
      builder: (context, _) {
        if (g.isOnline) return const SizedBox.shrink();
        final text = !g.userEnabled
            ? 'اینترنت برنامه قطع است — هیچ داده‌ای ارسال نمی‌شود'
            : 'گوشی به اینترنت وصل نیست';
        return Container(
          width: double.infinity,
          color: Colors.red.shade700,
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 13),
          ),
        );
      },
    );
  }
}
