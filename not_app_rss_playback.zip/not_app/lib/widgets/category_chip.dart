// ─────────────────────────────────────────────
// lib/widgets/category_chip.dart
// چیپ دسته‌بندی
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../data/categories.dart';

class CategoryChip extends StatelessWidget {
  final AppCategory category;
  final VoidCallback onTap;

  const CategoryChip({super.key, required this.category, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(category.icon, size: 18),
      label: Text(category.name),
      onPressed: onTap,
    );
  }
}
