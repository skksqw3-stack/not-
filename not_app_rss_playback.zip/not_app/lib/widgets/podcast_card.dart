// ─────────────────────────────────────────────
// lib/widgets/podcast_card.dart
// PodcastImage: تصویر با کش؛ در حالت آفلاین خاکستری می‌شود
// PodcastCard: کارت مربعی پادکست با انیمیشن Hero
// openPodcast: بررسی اینترنت و باز کردن صفحهٔ جزئیات
// ─────────────────────────────────────────────
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/podcast.dart';
import '../pages/podcast_detail_page.dart';
import '../services/network_guard.dart';
import '../theme/app_theme.dart';

class PodcastImage extends StatelessWidget {
  final String url;
  final double? size;
  final double radius;
  final BoxFit fit;

  const PodcastImage({
    super.key,
    required this.url,
    this.size,
    this.radius = 12,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    final g = NetworkGuard.instance;
    final grey = Theme.of(context).colorScheme.surfaceContainerHighest;

    Widget placeholder([IconData icon = Icons.podcasts]) => Container(
          color: grey,
          alignment: Alignment.center,
          child: Icon(icon, color: Theme.of(context).colorScheme.outline),
        );

    return StreamBuilder<bool>(
      stream: g.statusStream,
      initialData: g.isOnline,
      builder: (context, _) {
        final child = (!g.isOnline || url.isEmpty)
            ? placeholder()
            : CachedNetworkImage(
                imageUrl: url,
                fit: fit,
                placeholder: (_, __) => placeholder(),
                errorWidget: (_, __, ___) => placeholder(Icons.broken_image_outlined),
              );
        return SizedBox(
          width: size,
          height: size,
          child: ClipRRect(borderRadius: BorderRadius.circular(radius), child: child),
        );
      },
    );
  }
}

void openPodcast(BuildContext context, Podcast p, [String heroPrefix = 'none']) {
  if (!NetworkGuard.instance.isOnline) {
    showAppSnack(context, 'ابتدا اینترنت را روشن کنید');
    return;
  }
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => PodcastDetailPage(podcast: p, heroTag: '$heroPrefix-${p.id}'),
    ),
  );
}

class PodcastCard extends StatelessWidget {
  final Podcast podcast;
  final String heroPrefix;

  const PodcastCard({super.key, required this.podcast, required this.heroPrefix});

  @override
  Widget build(BuildContext context) {
    final g = NetworkGuard.instance;
    return StreamBuilder<bool>(
      stream: g.statusStream,
      initialData: g.isOnline,
      builder: (context, _) {
        return Opacity(
          opacity: g.isOnline ? 1 : 0.5,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => openPodcast(context, podcast, heroPrefix),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AspectRatio(
                  aspectRatio: 1,
                  child: Hero(
                    tag: '$heroPrefix-${podcast.id}',
                    child: PodcastImage(url: podcast.imageUrl, radius: 16),
                  ),
                ),
                const SizedBox(height: 8),
                Text(podcast.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(podcast.author,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ),
          ),
        );
      },
    );
  }
}
