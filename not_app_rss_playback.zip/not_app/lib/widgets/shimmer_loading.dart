// ─────────────────────────────────────────────
// lib/widgets/shimmer_loading.dart
// اسکلت‌های بارگذاری (Shimmer)
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class _Shimmer extends StatelessWidget {
  final Widget child;
  const _Shimmer({required this.child});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: dark ? Colors.grey.shade800 : Colors.grey.shade300,
      highlightColor: dark ? Colors.grey.shade700 : Colors.grey.shade100,
      child: child,
    );
  }
}

Widget _box({double? w, double? h, double r = 12}) => Container(
      width: w,
      height: h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(r),
      ),
    );

/// لیست افقی کارت‌های مربعی
class ShimmerHList extends StatelessWidget {
  final double itemSize;
  const ShimmerHList({super.key, this.itemSize = 150});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: itemSize + 56,
      child: _Shimmer(
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: 4,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, __) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _box(w: itemSize, h: itemSize),
              const SizedBox(height: 8),
              _box(w: itemSize * .8, h: 12, r: 6),
              const SizedBox(height: 6),
              _box(w: itemSize * .5, h: 10, r: 6),
            ],
          ),
        ),
      ),
    );
  }
}

/// لیست عمودی ردیف‌ها (برای اپیزودها)
class ShimmerList extends StatelessWidget {
  final int count;
  const ShimmerList({super.key, this.count = 5});

  @override
  Widget build(BuildContext context) {
    return _Shimmer(
      child: Column(
        children: List.generate(
          count,
          (_) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                _box(w: 52, h: 52, r: 8),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _box(h: 14, r: 6),
                      const SizedBox(height: 8),
                      _box(w: 120, h: 10, r: 6),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// شبکهٔ دو ستونه
class ShimmerGrid extends StatelessWidget {
  const ShimmerGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return _Shimmer(
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: .72,
        children: List.generate(4, (_) => _box()),
      ),
    );
  }
}
