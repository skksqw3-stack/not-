// ─────────────────────────────────────────────
// lib/data/categories.dart
// دسته‌بندی‌های برنامه
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

class AppCategory {
  final String name;
  final IconData icon;
  const AppCategory(this.name, this.icon);
}

const List<AppCategory> appCategories = [
  AppCategory('مستند', Icons.theaters),
  AppCategory('طنز', Icons.emoji_emotions_outlined),
  AppCategory('فناوری', Icons.memory),
  AppCategory('تاریخ', Icons.account_balance),
  AppCategory('فلسفه', Icons.psychology_alt),
  AppCategory('اجتماعی', Icons.groups),
  AppCategory('کتاب', Icons.menu_book),
  AppCategory('کودک', Icons.child_care),
  AppCategory('گفتگو', Icons.forum_outlined),
  AppCategory('خبری', Icons.newspaper),
];
