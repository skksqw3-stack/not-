// ─────────────────────────────────────────────
// lib/providers/history_provider.dart
// تاریخچهٔ شنیدن: episodeId، podcastId، position، timestamp
// (+ خود اپیزود برای نمایش در «ادامه گوش دادن»)
// ─────────────────────────────────────────────
import 'package:flutter/foundation.dart';

import '../models/episode.dart';
import '../services/storage_service.dart';

class HistoryEntry {
  final Episode episode;
  final Duration position;
  final DateTime timestamp;

  const HistoryEntry(this.episode, this.position, this.timestamp);

  bool get inProgress {
    if (position.inSeconds <= 5) return false;
    if (episode.duration == Duration.zero) return true;
    return position < episode.duration - const Duration(seconds: 10);
  }

  double get progress => episode.duration.inMilliseconds == 0
      ? 0
      : (position.inMilliseconds / episode.duration.inMilliseconds).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {
        'episodeId': episode.id,
        'podcastId': episode.podcastId,
        'position': position.inSeconds,
        'timestamp': timestamp.toIso8601String(),
        'episode': episode.toJson(),
      };

  static HistoryEntry? fromJson(Map<String, dynamic> j) {
    try {
      return HistoryEntry(
        Episode.fromJson(Map<String, dynamic>.from(j['episode'] as Map)),
        Duration(seconds: (j['position'] ?? 0) as int),
        DateTime.tryParse(j['timestamp'] as String? ?? '') ?? DateTime.now(),
      );
    } catch (_) {
      return null;
    }
  }
}

class HistoryProvider extends ChangeNotifier {
  static const _max = 50;
  final _s = StorageService.instance;
  final List<HistoryEntry> _entries = [];

  HistoryProvider() {
    for (final j in _s.history) {
      final e = HistoryEntry.fromJson(j);
      if (e != null) _entries.add(e);
    }
  }

  List<HistoryEntry> get entries => List.unmodifiable(_entries);
  List<HistoryEntry> get inProgress => _entries.where((e) => e.inProgress).toList();
  int get heardCount => _entries.length;

  Duration positionFor(String episodeId) {
    for (final e in _entries) {
      if (e.episode.id == episodeId) {
        // اگر تقریباً تمام شده، از اول شروع کن
        return e.inProgress ? e.position : Duration.zero;
      }
    }
    return Duration.zero;
  }

  Future<void> record(Episode episode, Duration position) async {
    _entries.removeWhere((e) => e.episode.id == episode.id);
    _entries.insert(0, HistoryEntry(episode, position, DateTime.now()));
    if (_entries.length > _max) _entries.removeRange(_max, _entries.length);
    notifyListeners();
    await _s.setHistory(_entries.map((e) => e.toJson()).toList());
  }
}
