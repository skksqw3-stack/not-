// ─────────────────────────────────────────────
// lib/providers/player_provider.dart
// پل بین AppAudioService و رابط کاربری.
// موقعیت پخش (position) عمداً اینجا notify نمی‌شود؛
// صفحه‌ها خودشان از positionStream استفاده می‌کنند.
// ─────────────────────────────────────────────
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../models/episode.dart';
import '../models/play_state.dart';
import '../services/audio_service.dart';
import '../services/network_guard.dart';
import 'history_provider.dart';

class PlayerProvider extends ChangeNotifier {
  final HistoryProvider _history;
  final AppAudioService _audio = AppAudioService.instance;
  final List<StreamSubscription> _subs = [];

  PlayState _state = const PlayState();
  DateTime _lastSave = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _sleepTimer;
  int? sleepMinutes;

  PlayerProvider(this._history) {
    _state = PlayState(episode: _audio.current, playing: _audio.playing);

    _subs.add(_audio.currentEpisodeStream.listen((e) {
      _state = _state.copyWith(episode: e, clearEpisode: e == null);
      notifyListeners();
    }));

    _subs.add(_audio.playerStateStream.listen((s) {
      final loading = s.processingState == ProcessingState.loading ||
          s.processingState == ProcessingState.buffering;
      final wasPlaying = _state.playing;
      _state = _state.copyWith(playing: s.playing, loading: loading);
      // هنگام توقف، جایگاه را ذخیره کن
      final e = _state.episode;
      if (wasPlaying && !s.playing && e != null) {
        _history.record(e, _audio.position);
      }
      notifyListeners();
    }));

    _subs.add(_audio.positionStream.listen(_onPosition));
  }

  void _onPosition(Duration p) {
    final e = _state.episode;
    if (e == null || !_state.playing) return;
    if (DateTime.now().difference(_lastSave).inSeconds >= 5) {
      _lastSave = DateTime.now();
      _history.record(e, p);
    }
  }

  // ───── وضعیت ─────
  PlayState get state => _state;
  Episode? get episode => _state.episode;
  bool get isPlaying => _state.playing;
  bool get isLoading => _state.loading;
  double get speed => _state.speed;

  // ───── کنترل ─────
  /// در صورت خطا، پیام فارسی برمی‌گرداند؛ در غیر این صورت null.
  Future<String?> playEpisode(Episode e, {List<Episode>? queue}) async {
    try {
      final resumeAt = _history.positionFor(e.id);
      await _audio.play(e, queue: queue, startAt: resumeAt);
      return null;
    } on NetworkBlockedException catch (ex) {
      return ex.message;
    } catch (_) {
      return 'پخش اپیزود ممکن نشد';
    }
  }

  Future<void> toggle() async {
    if (_state.episode == null) return;
    if (_state.playing) {
      await _audio.pause();
    } else {
      await _audio.resume();
    }
  }

  Future<void> seek(Duration d) => _audio.seek(d);
  Future<void> skipForward() => _audio.skipForward();
  Future<void> skipBackward() => _audio.skipBackward();
  Future<void> next() => _audio.next();
  Future<void> previous() => _audio.previous();

  Future<void> setSpeed(double s) async {
    await _audio.setSpeed(s);
    _state = _state.copyWith(speed: s);
    notifyListeners();
  }

  Future<void> close() async {
    final e = _state.episode;
    if (e != null) await _history.record(e, _audio.position);
    await _audio.stop();
  }

  // ───── تایمر خواب ─────
  void setSleepTimer(int? minutes) {
    _sleepTimer?.cancel();
    sleepMinutes = minutes;
    if (minutes != null) {
      _sleepTimer = Timer(Duration(minutes: minutes), () {
        _audio.pause();
        sleepMinutes = null;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _sleepTimer?.cancel();
    super.dispose();
  }
}
