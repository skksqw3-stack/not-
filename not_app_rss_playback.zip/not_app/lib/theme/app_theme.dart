// ─────────────────────────────────────────────
// lib/theme/app_theme.dart
// تم Material 3 (روشن/تاریک) با رنگ نارنجی CastBox و فونت Vazirmatn
// به‌همراه ThemeProvider و یک تابع کمکی برای SnackBar
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/storage_service.dart';

class AppTheme {
  static const Color primary = Color(0xFFF26522);

  static ThemeData light() => _build(Brightness.light);
  static ThemeData dark() => _build(Brightness.dark);

  static ThemeData _build(Brightness b) {
    final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: b);
    final base = ThemeData(useMaterial3: true, colorScheme: scheme);
    return base.copyWith(
      textTheme: GoogleFonts.vazirmatnTextTheme(base.textTheme),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: scheme.surface,
      ),
      navigationBarTheme:
          NavigationBarThemeData(indicatorColor: scheme.primaryContainer),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}

class ThemeProvider extends ChangeNotifier {
  bool _dark = StorageService.instance.darkMode;

  bool get isDark => _dark;
  ThemeMode get mode => _dark ? ThemeMode.dark : ThemeMode.light;

  Future<void> setDark(bool v) async {
    _dark = v;
    notifyListeners();
    await StorageService.instance.setDarkMode(v);
  }
}

void showAppSnack(BuildContext context, String message) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(message)));
}
