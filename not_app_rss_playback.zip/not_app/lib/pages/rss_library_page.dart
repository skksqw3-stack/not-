import 'package:flutter/material.dart';

import '../models/podcast.dart';
import '../services/rss_service.dart';
import '../services/storage_service.dart';
import '../widgets/podcast_card.dart';

/// کتابخانهٔ فیدهایی که کاربر با لینک RSS به برنامه اضافه می‌کند.
class RssLibraryPage extends StatefulWidget {
  const RssLibraryPage({super.key});

  @override
  State<RssLibraryPage> createState() => _RssLibraryPageState();
}

class _RssLibraryPageState extends State<RssLibraryPage> {
  final _storage = StorageService.instance;
  late List<Podcast> _podcasts;
  bool _adding = false;

  @override
  void initState() {
    super.initState();
    _podcasts = _readSaved();
  }

  List<Podcast> _readSaved() {
    final result = <Podcast>[];
    for (final json in _storage.customPodcasts) {
      try {
        result.add(Podcast.fromJson(json));
      } catch (_) {}
    }
    return result;
  }

  Future<void> _save() => _storage.setCustomPodcasts(
        _podcasts.map((podcast) => podcast.toJson()).toList(),
      );

  Future<void> _showAddDialog() async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('افزودن پادکست با RSS'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('لینک مستقیم RSS پادکست را وارد کنید. لینک صفحه وب یا لینک اشتراک‌گذاری معمولی کافی نیست.'),
            const SizedBox(height: 14),
            TextField(
              controller: controller,
              autofocus: true,
              keyboardType: TextInputType.url,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                hintText: 'https://example.com/podcast/rss',
                labelText: 'نشانی RSS',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim()),
            child: const Text('بررسی و افزودن'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (url == null || url.trim().isEmpty || !mounted) return;
    await _addFeed(url);
  }

  Future<void> _addFeed(String url) async {
    setState(() => _adding = true);
    try {
      final podcast = await RssService.podcastFromFeed(url);
      if (!mounted) return;
      if (_podcasts.any((p) => p.feedUrl.toLowerCase() == podcast.feedUrl.toLowerCase())) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('این پادکست قبلاً اضافه شده است.')),
        );
        return;
      }
      setState(() => _podcasts.insert(0, podcast));
      await _save();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('«${podcast.title}» اضافه شد.')),
      );
    } catch (error) {
      if (!mounted) return;
      final message = error.toString().replaceFirst('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 5)),
      );
    } finally {
      if (mounted) setState(() => _adding = false);
    }
  }

  Future<void> _remove(Podcast podcast) async {
    setState(() => _podcasts.removeWhere((p) => p.id == podcast.id));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پادکست‌های RSS من'),
        actions: [
          IconButton(
            tooltip: 'افزودن RSS',
            onPressed: _adding ? null : _showAddDialog,
            icon: const Icon(Icons.add_link),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _adding ? null : _showAddDialog,
        icon: _adding
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.add),
        label: Text(_adding ? 'در حال بررسی فید...' : 'افزودن پادکست'),
      ),
      body: _podcasts.isEmpty
          ? ListView(
              padding: const EdgeInsets.all(28),
              children: const [
                SizedBox(height: 70),
                Icon(Icons.rss_feed, size: 72, color: Colors.orange),
                SizedBox(height: 18),
                Text('هنوز پادکستی اضافه نکرده‌اید', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text('لینک RSS پادکست را وارد کنید. نُت فید را بررسی می‌کند، عنوان و تصویر و اپیزودها را می‌خواند و امکان پخش داخل برنامه را فراهم می‌کند.',
                    textAlign: TextAlign.center),
              ],
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: .72,
              ),
              itemCount: _podcasts.length,
              itemBuilder: (context, index) {
                final podcast = _podcasts[index];
                return Stack(
                  children: [
                    Positioned.fill(
                      child: PodcastCard(podcast: podcast, heroPrefix: 'rss-library'),
                    ),
                    Positioned(
                      top: 2,
                      left: 2,
                      child: Material(
                        color: Theme.of(context).colorScheme.surface.withOpacity(.9),
                        shape: const CircleBorder(),
                        child: IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'حذف از فهرست من',
                          icon: const Icon(Icons.delete_outline, size: 20),
                          onPressed: () => _remove(podcast),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
    );
  }
}
