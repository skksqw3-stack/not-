// ─────────────────────────────────────────────
// lib/pages/search_page.dart
// جستجوی محلی در نام پادکست و نویسنده + تاریخچهٔ جستجو
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../data/castbox_podcasts.dart';
import '../models/podcast.dart';
import '../services/storage_service.dart';
import '../widgets/empty_state.dart';
import '../widgets/podcast_card.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _controller = TextEditingController();
  final _storage = StorageService.instance;
  late List<String> _history;
  late List<Podcast> _customPodcasts;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _history = _storage.searchHistory;
    _customPodcasts = _storage.customPodcasts
        .map((json) {
          try { return Podcast.fromJson(json); } catch (_) { return null; }
        })
        .whereType<Podcast>()
        .toList();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// یکسان‌سازی ی/ک عربی و فارسی و حذف نیم‌فاصله
  String _norm(String s) => s
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('\u200c', ' ')
      .toLowerCase()
      .trim();

  void _submit(String q) {
    final t = q.trim();
    if (t.isEmpty) return;
    _history
      ..remove(t)
      ..insert(0, t);
    if (_history.length > 10) _history = _history.sublist(0, 10);
    _storage.setSearchHistory(_history);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final q = _norm(_query);
    final List<Podcast> results = q.isEmpty
        ? const <Podcast>[]
        : [...castBoxPodcasts, ..._customPodcasts]
            .where((p) => _norm(p.title).contains(q) || _norm(p.author).contains(q))
            .toList();

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
            hintText: 'جستجوی پادکست یا نویسنده',
            border: InputBorder.none,
          ),
          onChanged: (v) => setState(() => _query = v),
          onSubmitted: _submit,
        ),
        actions: [
          if (_query.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                _controller.clear();
                setState(() => _query = '');
              },
            ),
        ],
      ),
      body: q.isEmpty ? _buildHistory() : _buildResults(results),
    );
  }

  Widget _buildResults(List<Podcast> results) {
    if (results.isEmpty) {
      return const EmptyState(
        icon: Icons.search_off,
        title: 'نتیجه‌ای پیدا نشد',
        message: 'عبارت دیگری را امتحان کنید',
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: .72,
      ),
      itemCount: results.length,
      itemBuilder: (_, i) {
        return PodcastCard(podcast: results[i], heroPrefix: 'search');
      },
    );
  }

  Widget _buildHistory() {
    if (_history.isEmpty) {
      return const EmptyState(
        icon: Icons.history,
        title: 'تاریخچهٔ جستجو خالی است',
      );
    }
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
          child: Row(
            children: [
              const Expanded(
                  child: Text('جستجوهای اخیر',
                      style: TextStyle(fontWeight: FontWeight.bold))),
              TextButton(
                onPressed: () {
                  setState(() => _history = []);
                  _storage.setSearchHistory([]);
                },
                child: const Text('پاک کردن'),
              ),
            ],
          ),
        ),
        for (final h in _history)
          ListTile(
            leading: const Icon(Icons.history),
            title: Text(h),
            trailing: IconButton(
              icon: const Icon(Icons.close, size: 18),
              onPressed: () {
                setState(() => _history.remove(h));
                _storage.setSearchHistory(_history);
              },
            ),
            onTap: () {
              _controller.text = h;
              _controller.selection = TextSelection.collapsed(offset: h.length);
              setState(() => _query = h);
            },
          ),
      ],
    );
  }
}
