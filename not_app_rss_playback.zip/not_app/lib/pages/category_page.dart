// ─────────────────────────────────────────────
// lib/pages/category_page.dart
// پادکست‌های یک دسته؛ اگر خالی بود EmptyState
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../data/castbox_podcasts.dart';
import '../data/categories.dart';
import '../widgets/empty_state.dart';
import '../widgets/podcast_card.dart';
import 'mini_player.dart';

class CategoryPage extends StatelessWidget {
  final AppCategory category;
  const CategoryPage({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final list = castBoxPodcasts.where((p) => p.category == category.name).toList();
    return Scaffold(
      appBar: AppBar(title: Text(category.name)),
      body: list.isEmpty
          ? EmptyState(
              icon: category.icon,
              title: 'هنوز پادکستی در این دسته نیست',
              message: 'به‌زودی پادکست‌های «${category.name}» اضافه می‌شود',
            )
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: .72,
              ),
              itemCount: list.length,
              itemBuilder: (_, i) =>
                  PodcastCard(podcast: list[i], heroPrefix: 'cat'),
            ),
      bottomNavigationBar: const MiniPlayer(),
    );
  }
}
