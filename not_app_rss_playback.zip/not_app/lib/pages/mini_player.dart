// ─────────────────────────────────────────────
// lib/pages/mini_player.dart
// مینی‌پلیر پایین صفحه (بالای BottomNav): تصویر، عنوان، پخش/توقف، بستن
// نوار پیشرفت نازک بالای آن. فقط وقتی اپیزودی فعال است نمایش داده می‌شود.
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/player_provider.dart';
import '../services/audio_service.dart';
import '../widgets/podcast_card.dart';
import 'player_page.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final e = player.episode;
    if (e == null) return const SizedBox.shrink();
    final cs = Theme.of(context).colorScheme;
    final audio = AppAudioService.instance;

    return Material(
      color: cs.surfaceContainerHighest,
      elevation: 6,
      child: InkWell(
        onTap: () => openPlayerPage(context),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            StreamBuilder<Duration>(
              stream: audio.positionStream,
              builder: (context, snap) {
                final pos = snap.data ?? Duration.zero;
                final dur = audio.duration ?? e.duration;
                final v = dur.inMilliseconds > 0
                    ? (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0)
                    : 0.0;
                return LinearProgressIndicator(value: v, minHeight: 2);
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  PodcastImage(url: e.imageUrl, size: 44, radius: 8),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(e.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text(e.podcastTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                      ],
                    ),
                  ),
                  if (player.isLoading)
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                    )
                  else
                    IconButton(
                      icon: Icon(player.isPlaying ? Icons.pause : Icons.play_arrow),
                      onPressed: player.toggle,
                    ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: player.close,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
