// ─────────────────────────────────────────────
// lib/pages/network_log_page.dart
// گزارش ۱۰۰ درخواست آخر شبکه (مجاز / مسدود) با آمار بالای صفحه
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../services/network_guard.dart';
import '../widgets/empty_state.dart';

class NetworkLogPage extends StatelessWidget {
  const NetworkLogPage({super.key});

  String _time(DateTime t) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(t.hour)}:${two(t.minute)}:${two(t.second)}';
  }

  @override
  Widget build(BuildContext context) {
    final g = NetworkGuard.instance;
    return Scaffold(
      appBar: AppBar(
        title: const Text('گزارش شبکه'),
        actions: [
          IconButton(
            tooltip: 'پاک کردن',
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: g.clearLogs,
          ),
        ],
      ),
      body: StreamBuilder<List<NetworkLogEntry>>(
        stream: g.logStream,
        initialData: g.logs,
        builder: (context, snap) {
          final logs = snap.data ?? const <NetworkLogEntry>[];
          if (logs.isEmpty) {
            return const EmptyState(
              icon: Icons.wifi_find,
              title: 'هنوز درخواستی ثبت نشده',
              message: 'درخواست‌های شبکهٔ برنامه اینجا نمایش داده می‌شود',
            );
          }
          final allowed = logs.where((l) => l.allowed).length;
          final blocked = logs.length - allowed;
          final reversed = logs.reversed.toList();

          Widget stat(String label, int v, Color c) => Expanded(
                child: Column(
                  children: [
                    Text('$v',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold, color: c)),
                    Text(label, style: const TextStyle(fontSize: 12)),
                  ],
                ),
              );

          return Column(
            children: [
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    stat('کل', logs.length, Theme.of(context).colorScheme.primary),
                    stat('مجاز', allowed, Colors.green),
                    stat('مسدود', blocked, Colors.red),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: reversed.length,
                  itemBuilder: (_, i) {
                    final l = reversed[i];
                    return ListTile(
                      dense: true,
                      leading: Icon(
                        l.allowed ? Icons.check_circle : Icons.block,
                        color: l.allowed ? Colors.green : Colors.red,
                      ),
                      title: Text(l.url,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.ltr,
                          textAlign: TextAlign.left),
                      trailing: Text(_time(l.time)),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
