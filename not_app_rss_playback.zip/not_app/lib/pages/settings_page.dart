// ─────────────────────────────────────────────
// lib/pages/settings_page.dart
// تنظیمات: کلید اینترنت، کیفیت پخش (placeholder)، حالت تاریک،
// پاک کردن حافظهٔ پنهان، گزارش شبکه، دربارهٔ برنامه
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../widgets/network_switch.dart';
import 'network_log_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(
        children: [
          const NetworkSwitch(),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.high_quality_outlined),
            title: const Text('کیفیت پخش'),
            subtitle: const Text('خودکار'),
            onTap: () => showAppSnack(context, 'به‌زودی'),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode_outlined),
            title: const Text('حالت تاریک'),
            value: theme.isDark,
            onChanged: theme.setDark,
          ),
          ListTile(
            leading: const Icon(Icons.cleaning_services_outlined),
            title: const Text('پاک کردن حافظهٔ پنهان'),
            subtitle: const Text('حذف تصاویر ذخیره‌شده'),
            onTap: () async {
              await DefaultCacheManager().emptyCache();
              if (context.mounted) showAppSnack(context, 'حافظهٔ پنهان پاک شد');
            },
          ),
          ListTile(
            leading: const Icon(Icons.receipt_long_outlined),
            title: const Text('گزارش شبکه'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const NetworkLogPage())),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('دربارهٔ برنامه'),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'نُت',
              applicationVersion: '1.0.0',
              applicationLegalese: 'اپلیکیشن پادکست با کنترل کامل اینترنت',
            ),
          ),
        ],
      ),
    );
  }
}
