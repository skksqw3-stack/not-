// ─────────────────────────────────────────────
// lib/pages/player_page.dart
// پخش‌کنندهٔ تمام‌صفحه: پس‌زمینهٔ blur، Slider، پرش ۱۵ ثانیه،
// قبلی/بعدی، سرعت پخش، تایمر خواب و علاقه‌مندی
// ─────────────────────────────────────────────
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/episode.dart';
import '../providers/favorites_provider.dart';
import '../providers/player_provider.dart';
import '../services/audio_service.dart';
import '../widgets/podcast_card.dart';

/// باز شدن با انیمیشن slide up
void openPlayerPage(BuildContext context) {
  Navigator.of(context, rootNavigator: true).push(
    PageRouteBuilder(
      pageBuilder: (_, __, ___) => const PlayerPage(),
      transitionDuration: const Duration(milliseconds: 350),
      reverseTransitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
            .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: child,
      ),
    ),
  );
}

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key});

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  double? _drag; // مقدار موقت هنگام کشیدن Slider (میلی‌ثانیه)
  static const _speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final favs = context.watch<FavoritesProvider>();
    final e = player.episode;
    final audio = AppAudioService.instance;

    if (e == null) {
      // پخش‌کننده بسته شده؛ صفحه را ببند
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.canPop(context)) Navigator.pop(context);
      });
      return const Scaffold();
    }

    const white = Colors.white;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // پس‌زمینهٔ blur
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
            child: PodcastImage(url: e.imageUrl, radius: 0),
          ),
          Container(color: Colors.black.withOpacity(.6)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.keyboard_arrow_down, color: white, size: 32),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                      const Text('در حال پخش', style: TextStyle(color: white)),
                      const Spacer(),
                      const SizedBox(width: 48),
                    ],
                  ),
                  Expanded(
                    child: Center(
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: const [
                            BoxShadow(color: Colors.black54, blurRadius: 30, offset: Offset(0, 12)),
                          ],
                        ),
                        child: AspectRatio(
                          aspectRatio: 1,
                          child: PodcastImage(url: e.imageUrl, radius: 24),
                        ),
                      ),
                    ),
                  ),
                  Text(e.title,
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: white, fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(e.podcastTitle,
                      style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 12),
                  _buildSlider(e, audio),
                  const SizedBox(height: 8),
                  _buildControls(player),
                  const SizedBox(height: 12),
                  _buildExtras(player, favs, e),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlider(Episode e, AppAudioService audio) {
    return StreamBuilder<Duration>(
      stream: audio.positionStream,
      builder: (context, posSnap) {
        final pos = posSnap.data ?? audio.position;
        return StreamBuilder<Duration?>(
          stream: audio.durationStream,
          builder: (context, durSnap) {
            final dur = durSnap.data ?? audio.duration ?? e.duration;
            final max = dur.inMilliseconds.toDouble().clamp(1.0, double.infinity).toDouble();
            final value = (_drag ?? pos.inMilliseconds.toDouble()).clamp(0.0, max).toDouble();
            return Column(
              children: [
                Slider(
                  value: value,
                  max: max,
                  activeColor: Colors.white,
                  inactiveColor: Colors.white24,
                  onChanged: (v) => setState(() => _drag = v),
                  onChangeEnd: (v) {
                    audio.seek(Duration(milliseconds: v.round()));
                    setState(() => _drag = null);
                  },
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(formatDuration(Duration(milliseconds: value.round())),
                          style: const TextStyle(color: Colors.white70)),
                      Text(formatDuration(dur),
                          style: const TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _skip(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 38),
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text(label,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControls(PlayerProvider player) {
    // ترتیب کنترل‌ها مثل پخش‌کننده‌های استاندارد (چپ‌به‌راست) ثابت می‌ماند
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            iconSize: 36,
            color: Colors.white,
            icon: const Icon(Icons.skip_previous),
            onPressed: player.previous,
          ),
          _skip(Icons.replay, '15', player.skipBackward),
          Container(
            width: 80,
            height: 80,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: player.isLoading
                ? const Padding(
                    padding: EdgeInsets.all(24),
                    child: CircularProgressIndicator(strokeWidth: 3, color: Colors.black),
                  )
                : IconButton(
                    iconSize: 48,
                    color: Colors.black,
                    icon: Icon(player.isPlaying ? Icons.pause : Icons.play_arrow),
                    onPressed: player.toggle,
                  ),
          ),
          _skip(Icons.refresh, '15', player.skipForward),
          IconButton(
            iconSize: 36,
            color: Colors.white,
            icon: const Icon(Icons.skip_next),
            onPressed: player.next,
          ),
        ],
      ),
    );
  }

  Widget _buildExtras(PlayerProvider player, FavoritesProvider favs, Episode e) {
    final fav = favs.isFavorite(e.id);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: Colors.white),
          icon: const Icon(Icons.speed),
          label: Text('${player.speed}x'),
          onPressed: () => _showSpeedSheet(player),
        ),
        TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: Colors.white),
          icon: Icon(player.sleepMinutes == null ? Icons.bedtime_outlined : Icons.bedtime),
          label: Text(player.sleepMinutes == null ? 'تایمر خواب' : '${player.sleepMinutes} دقیقه'),
          onPressed: () => _showSleepSheet(player),
        ),
        IconButton(
          color: fav ? Colors.redAccent : Colors.white,
          icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
          onPressed: () => favs.toggleFavorite(e),
        ),
      ],
    );
  }

  void _showSpeedSheet(PlayerProvider player) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('سرعت پخش', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            for (final s in _speeds)
              ListTile(
                title: Text('${s}x'),
                trailing: player.speed == s ? const Icon(Icons.check) : null,
                onTap: () {
                  player.setSpeed(s);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _showSleepSheet(PlayerProvider player) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('تایمر خواب', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            for (final m in [15, 30, 45, 60])
              ListTile(
                title: Text('$m دقیقه'),
                trailing: player.sleepMinutes == m ? const Icon(Icons.check) : null,
                onTap: () {
                  player.setSleepTimer(m);
                  Navigator.pop(ctx);
                },
              ),
            ListTile(
              leading: const Icon(Icons.timer_off_outlined),
              title: const Text('خاموش'),
              onTap: () {
                player.setSleepTimer(null);
                Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
  }
}
