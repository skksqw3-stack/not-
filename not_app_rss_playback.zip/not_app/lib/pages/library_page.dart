// ─────────────────────────────────────────────
// lib/pages/library_page.dart
// تب کتابخانه: اشتراک‌ها | علاقه‌مندی‌ها | دانلودها
// حذف با Swipe (flutter_slidable)
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:provider/provider.dart';

import '../providers/favorites_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/episode_tile.dart';
import '../widgets/podcast_card.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('کتابخانه'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'اشتراک‌ها'),
              Tab(text: 'علاقه‌مندی‌ها'),
              Tab(text: 'دانلودها'),
            ],
          ),
        ),
        body: Consumer<FavoritesProvider>(
          builder: (context, favs, _) {
            final subs = favs.subscribedPodcasts;
            final eps = favs.favoriteEpisodes;
            return TabBarView(
              children: [
                // اشتراک‌ها
                subs.isEmpty
                    ? const EmptyState(
                        icon: Icons.podcasts,
                        title: 'هنوز پادکستی دنبال نکرده‌اید',
                        message: 'در صفحهٔ هر پادکست دکمهٔ «اشتراک» را بزنید',
                      )
                    : ListView.builder(
                        itemCount: subs.length,
                        itemBuilder: (_, i) {
                          final p = subs[i];
                          return Slidable(
                            key: ValueKey('sub-${p.id}'),
                            endActionPane: ActionPane(
                              motion: const DrawerMotion(),
                              children: [
                                SlidableAction(
                                  onPressed: (_) => favs.toggleSubscription(p.id),
                                  backgroundColor: Colors.red,
                                  foregroundColor: Colors.white,
                                  icon: Icons.delete_outline,
                                  label: 'لغو اشتراک',
                                ),
                              ],
                            ),
                            child: ListTile(
                              leading: PodcastImage(url: p.imageUrl, size: 52, radius: 10),
                              title: Text(p.title),
                              subtitle: Text(p.author),
                              onTap: () => openPodcast(context, p, 'lib'),
                            ),
                          );
                        },
                      ),

                // علاقه‌مندی‌ها
                eps.isEmpty
                    ? const EmptyState(
                        icon: Icons.favorite_border,
                        title: 'علاقه‌مندی‌ها خالی است',
                        message: 'روی قلب هر اپیزود بزنید تا اینجا ذخیره شود',
                      )
                    : ListView.builder(
                        itemCount: eps.length,
                        itemBuilder: (_, i) {
                          final e = eps[i];
                          return Slidable(
                            key: ValueKey('fav-${e.id}'),
                            endActionPane: ActionPane(
                              motion: const DrawerMotion(),
                              children: [
                                SlidableAction(
                                  onPressed: (_) => favs.toggleFavorite(e),
                                  backgroundColor: Colors.red,
                                  foregroundColor: Colors.white,
                                  icon: Icons.delete_outline,
                                  label: 'حذف',
                                ),
                              ],
                            ),
                            child: EpisodeTile(episode: e, queue: eps),
                          );
                        },
                      ),

                // دانلودها (placeholder)
                const EmptyState(
                  icon: Icons.download_for_offline_outlined,
                  title: 'به‌زودی',
                  message: 'دانلود اپیزودها برای شنیدن آفلاین به‌زودی اضافه می‌شود',
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
