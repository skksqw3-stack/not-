// ─────────────────────────────────────────────
// lib/services/http_guard.dart
// مهم‌ترین لایه: HttpOverrides سراسری که تمام درخواست‌های dart:io
// (از جمله http و cached_network_image) را قبل از ارسال بررسی می‌کند.
// اگر NetworkGuard اجازه ندهد، SocketException پرتاب می‌شود.
//
// نکته: تمام اعضای HttpClient صریحاً پیاده شده‌اند؛ noSuchMethod فقط برای
// اعضای جدیدتر SDK (مثل keyLog / connectionFactory) به‌عنوان پشتیبان است.
// ─────────────────────────────────────────────
import 'dart:async';
import 'dart:io';

import 'network_guard.dart';

class HttpGuard extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) =>
      GuardedHttpClient(super.createHttpClient(context));
}

class GuardedHttpClient implements HttpClient {
  final HttpClient _inner;
  GuardedHttpClient(this._inner);

  void _check(Uri uri) {
    if (!NetworkGuard.instance.allowRequest(uri.toString())) {
      throw SocketException(
          'اینترنت برنامه قطع است (مسدود توسط NetworkGuard): ${uri.host}');
    }
  }

  Uri _uri(String host, int port, String path) {
    final scheme = port == 443 ? 'https' : 'http';
    final p = path.startsWith('/') ? path : '/$path';
    try {
      return Uri.parse('$scheme://$host:$port$p');
    } catch (_) {
      return Uri(scheme: scheme, host: host, port: port);
    }
  }

  // ───── متدهای اصلی ─────
  @override
  Future<HttpClientRequest> open(
      String method, String host, int port, String path) async {
    _check(_uri(host, port, path));
    return _inner.open(method, host, port, path);
  }

  @override
  Future<HttpClientRequest> openUrl(String method, Uri url) async {
    _check(url);
    return _inner.openUrl(method, url);
  }

  @override
  Future<HttpClientRequest> get(String host, int port, String path) =>
      open('GET', host, port, path);
  @override
  Future<HttpClientRequest> getUrl(Uri url) => openUrl('GET', url);

  @override
  Future<HttpClientRequest> post(String host, int port, String path) =>
      open('POST', host, port, path);
  @override
  Future<HttpClientRequest> postUrl(Uri url) => openUrl('POST', url);

  @override
  Future<HttpClientRequest> put(String host, int port, String path) =>
      open('PUT', host, port, path);
  @override
  Future<HttpClientRequest> putUrl(Uri url) => openUrl('PUT', url);

  @override
  Future<HttpClientRequest> delete(String host, int port, String path) =>
      open('DELETE', host, port, path);
  @override
  Future<HttpClientRequest> deleteUrl(Uri url) => openUrl('DELETE', url);

  @override
  Future<HttpClientRequest> head(String host, int port, String path) =>
      open('HEAD', host, port, path);
  @override
  Future<HttpClientRequest> headUrl(Uri url) => openUrl('HEAD', url);

  @override
  Future<HttpClientRequest> patch(String host, int port, String path) =>
      open('PATCH', host, port, path);
  @override
  Future<HttpClientRequest> patchUrl(Uri url) => openUrl('PATCH', url);

  // ───── getter / setter ها ─────
  @override
  Duration get idleTimeout => _inner.idleTimeout;
  @override
  set idleTimeout(Duration v) => _inner.idleTimeout = v;

  @override
  Duration? get connectionTimeout => _inner.connectionTimeout;
  @override
  set connectionTimeout(Duration? v) => _inner.connectionTimeout = v;

  @override
  int? get maxConnectionsPerHost => _inner.maxConnectionsPerHost;
  @override
  set maxConnectionsPerHost(int? v) => _inner.maxConnectionsPerHost = v;

  @override
  bool get autoUncompress => _inner.autoUncompress;
  @override
  set autoUncompress(bool v) => _inner.autoUncompress = v;

  @override
  String? get userAgent => _inner.userAgent;
  @override
  set userAgent(String? v) => _inner.userAgent = v;

  @override
  void addCredentials(
          Uri url, String realm, HttpClientCredentials credentials) =>
      _inner.addCredentials(url, realm, credentials);

  @override
  void addProxyCredentials(String host, int port, String realm,
          HttpClientCredentials credentials) =>
      _inner.addProxyCredentials(host, port, realm, credentials);

  @override
  set authenticate(
          Future<bool> Function(Uri url, String scheme, String? realm)? f) =>
      _inner.authenticate = f;

  @override
  set authenticateProxy(
          Future<bool> Function(
                  String host, int port, String scheme, String? realm)?
              f) =>
      _inner.authenticateProxy = f;

  @override
  set badCertificateCallback(
          bool Function(X509Certificate cert, String host, int port)?
              callback) =>
      _inner.badCertificateCallback = callback;

  @override
  set findProxy(String Function(Uri url)? f) => _inner.findProxy = f;

  @override
  void close({bool force = false}) => _inner.close(force: force);

  // پشتیبان برای اعضای جدیدتر در نسخه‌های آیندهٔ SDK
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}
