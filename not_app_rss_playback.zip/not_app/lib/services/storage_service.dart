// ─────────────────────────────────────────────
// lib/services/storage_service.dart
// ذخیره‌سازی با SharedPreferences:
// favorites (شناسه‌ها)، favoriteData (JSON اپیزودها برای نمایش در کتابخانه)،
// subscriptions، history، searchHistory، darkMode
// (userEnabled توسط NetworkGuard ذخیره می‌شود)
// ─────────────────────────────────────────────
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  late SharedPreferences _p;

  Future<void> init() async {
    try {
      _p = await SharedPreferences.getInstance();
    } catch (_) {
      // در محیط‌هایی که پلاگین ذخیره‌سازی در دسترس نیست، حافظهٔ موقت
      // اجازه می‌دهد برنامه همچنان اجرا شود و صفحه سفید نماند.
      SharedPreferences.setMockInitialValues(<String, Object>{});
      _p = await SharedPreferences.getInstance();
    }
  }

  // ───── علاقه‌مندی‌ها ─────
  Set<String> get favorites => (_p.getStringList('favorites') ?? []).toSet();
  Future<void> setFavorites(Set<String> v) =>
      _p.setStringList('favorites', v.toList());

  List<Map<String, dynamic>> get favoriteData => _readJsonList('favoriteData');
  Future<void> setFavoriteData(List<Map<String, dynamic>> v) =>
      _writeJsonList('favoriteData', v);

  // ───── اشتراک‌ها ─────
  Set<String> get subscriptions =>
      (_p.getStringList('subscriptions') ?? []).toSet();
  Future<void> setSubscriptions(Set<String> v) =>
      _p.setStringList('subscriptions', v.toList());

  // ───── فیدهای RSS که کاربر وارد کرده است ─────
  List<Map<String, dynamic>> get customPodcasts => _readJsonList('customPodcasts');
  Future<void> setCustomPodcasts(List<Map<String, dynamic>> v) =>
      _writeJsonList('customPodcasts', v);

  // ───── تاریخچهٔ شنیدن ─────
  List<Map<String, dynamic>> get history => _readJsonList('history');
  Future<void> setHistory(List<Map<String, dynamic>> v) =>
      _writeJsonList('history', v);

  // ───── تاریخچهٔ جستجو ─────
  List<String> get searchHistory => _p.getStringList('searchHistory') ?? [];
  Future<void> setSearchHistory(List<String> v) =>
      _p.setStringList('searchHistory', v);

  // ───── تم ─────
  bool get darkMode => _p.getBool('darkMode') ?? false;
  Future<void> setDarkMode(bool v) => _p.setBool('darkMode', v);

  // ───── کمکی ─────
  List<Map<String, dynamic>> _readJsonList(String key) {
    final raw = _p.getStringList(key) ?? [];
    final out = <Map<String, dynamic>>[];
    for (final s in raw) {
      try {
        out.add(Map<String, dynamic>.from(jsonDecode(s) as Map));
      } catch (_) {}
    }
    return out;
  }

  Future<void> _writeJsonList(String key, List<Map<String, dynamic>> v) =>
      _p.setStringList(key, v.map(jsonEncode).toList());
}
