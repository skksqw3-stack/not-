// دریافت و پردازش RSS/Atom پادکست‌ها. از نمونه‌سازی اپیزود جعلی خودداری می‌شود.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

import '../models/episode.dart';
import '../models/podcast.dart';
import 'network_guard.dart';

class RssService {
  static const _userAgent = 'NotApp/1.1 (Flutter Podcast RSS Reader)';

  static Future<String> _download(String feedUrl) async {
    final uri = Uri.tryParse(feedUrl.trim());
    if (uri == null || !uri.hasScheme || !['http', 'https'].contains(uri.scheme)) {
      throw Exception('لینک باید یک نشانی معتبر HTTP یا HTTPS باشد.');
    }
    if (!NetworkGuard.instance.allowRequest(uri.toString())) {
      throw const NetworkBlockedException('دسترسی اینترنت در تنظیمات برنامه غیرفعال است.');
    }
    try {
      final response = await http.get(uri, headers: {
        'User-Agent': _userAgent,
        'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*',
      }).timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) {
        throw Exception('سرور فید پاسخ ${response.statusCode} برگرداند.');
      }
      final body = utf8.decode(response.bodyBytes, allowMalformed: true);
      if (body.trim().isEmpty) throw Exception('محتوای فید خالی است.');
      return body;
    } on SocketException {
      throw Exception('اتصال اینترنت برقرار نیست.');
    } on TimeoutException {
      throw Exception('زمان دریافت فید به پایان رسید. دوباره تلاش کنید.');
    } on FormatException {
      throw Exception('نشانی فید معتبر نیست.');
    }
  }

  /// لینک RSS را اعتبارسنجی می‌کند و مشخصات پادکست را از خود فید می‌خواند.
  /// فقط وقتی حداقل یک اپیزود صوتی واقعی وجود داشته باشد آن را می‌پذیرد.
  static Future<Podcast> podcastFromFeed(String feedUrl) async {
    final normalizedUrl = feedUrl.trim();
    final body = await _download(normalizedUrl);
    final doc = XmlDocument.parse(body);
    final root = doc.rootElement;
    final channel = _firstDescendant(root, const {'channel'}) ?? root;

    final title = _childText(channel, const {'title'}) ?? 'پادکست واردشده';
    final author = _childText(channel, const {'author', 'creator', 'managingEditor'}) ?? 'ناشناس';
    final description = _clean(_childText(channel, const {'description', 'subtitle', 'summary'}) ?? '');
    final image = _imageFrom(channel) ?? _imageFrom(root) ?? '';
    final idPart = base64Url.encode(utf8.encode(normalizedUrl)).replaceAll('=', '');
    final podcast = Podcast(
      id: 'rss_$idPart',
      title: title,
      author: author,
      imageUrl: image,
      feedUrl: normalizedUrl,
      description: description,
      category: 'واردشده',
    );
    final episodes = _parse(body, podcast);
    if (episodes.isEmpty) {
      throw Exception('این لینک معتبر به نظر می‌رسد، اما اپیزود صوتی قابل پخشی در آن پیدا نشد. لینک RSS پادکست را وارد کنید، نه لینک صفحه وب.');
    }
    return podcast;
  }

  static Future<List<Episode>> fetchEpisodes(Podcast podcast) async {
    if (podcast.feedUrl.trim().isEmpty) return <Episode>[];
    final body = await _download(podcast.feedUrl);
    try {
      return _parse(body, podcast);
    } on XmlException {
      throw Exception('ساختار XML فید معتبر نیست.');
    }
  }

  static List<Episode> _parse(String body, Podcast podcast) {
    final doc = XmlDocument.parse(body);
    final elements = doc.descendants.whereType<XmlElement>().where((e) =>
        e.name.local == 'item' || e.name.local == 'entry');
    final episodes = <Episode>[];
    for (final item in elements) {
      final audioUrl = _audioUrl(item, podcast.feedUrl);
      if (audioUrl == null || audioUrl.isEmpty) continue;
      final guid = _childText(item, const {'guid', 'id'}) ?? audioUrl;
      final rawDesc = _childText(item, const {'description', 'summary', 'content', 'encoded'}) ?? '';
      final itemImage = _imageFrom(item);
      episodes.add(Episode(
        id: '${podcast.id}|$guid',
        podcastId: podcast.id,
        podcastTitle: podcast.title,
        title: _childText(item, const {'title'}) ?? 'بدون عنوان',
        description: _clean(rawDesc),
        audioUrl: audioUrl,
        imageUrl: itemImage ?? podcast.imageUrl,
        pubDate: _parseDate(_childText(item, const {'pubDate', 'published', 'updated', 'date'})),
        duration: _parseDuration(_childText(item, const {'duration'})),
      ));
    }
    episodes.sort((a, b) {
      if (a.pubDate == null && b.pubDate == null) return 0;
      if (a.pubDate == null) return 1;
      if (b.pubDate == null) return -1;
      return b.pubDate!.compareTo(a.pubDate!);
    });
    return episodes;
  }

  static String? _audioUrl(XmlElement item, String feedUrl) {
    for (final element in item.childElements) {
      final local = element.name.local;
      if (local == 'enclosure') {
        final url = element.getAttribute('url');
        final type = element.getAttribute('type') ?? '';
        if (url != null && url.isNotEmpty &&
            (type.isEmpty || type.startsWith('audio/') || type == 'application/octet-stream')) {
          return _resolveUrl(feedUrl, url);
        }
      }
      if (local == 'link') {
        final href = element.getAttribute('href');
        final rel = element.getAttribute('rel') ?? 'alternate';
        final type = element.getAttribute('type') ?? '';
        if (href != null && href.isNotEmpty && (rel == 'enclosure' || type.startsWith('audio/'))) {
          return _resolveUrl(feedUrl, href);
        }
      }
    }
    return null;
  }

  static String? _resolveUrl(String base, String value) {
    final parsed = Uri.tryParse(value);
    if (parsed == null) return null;
    final resolved = parsed.hasScheme ? parsed : Uri.parse(base).resolveUri(parsed);
    if (resolved.scheme != 'http' && resolved.scheme != 'https') return null;
    return resolved.toString();
  }

  static XmlElement? _firstDescendant(XmlElement root, Set<String> names) {
    for (final e in root.descendants.whereType<XmlElement>()) {
      if (names.contains(e.name.local)) return e;
    }
    return null;
  }

  static String? _childText(XmlElement element, Set<String> names) {
    for (final child in element.childElements) {
      if (names.contains(child.name.local)) {
        final value = child.innerText.trim();
        if (value.isNotEmpty) return value;
      }
    }
    // بعضی فیدها metadata را در لایه‌های تو در تو قرار می‌دهند.
    for (final child in element.descendants.whereType<XmlElement>()) {
      if (names.contains(child.name.local)) {
        final value = child.innerText.trim();
        if (value.isNotEmpty) return value;
      }
    }
    return null;
  }

  static String? _imageFrom(XmlElement element) {
    for (final e in element.descendants.whereType<XmlElement>()) {
      if (e.name.local == 'image' || e.name.local == 'logo' || e.name.local == 'icon') {
        final href = e.getAttribute('href');
        if (href != null && href.startsWith('http')) return href;
        final url = e.getAttribute('url');
        if (url != null && url.startsWith('http')) return url;
        final nested = e.childElements.where((x) => x.name.local == 'url').firstOrNull;
        if (nested != null && nested.innerText.trim().startsWith('http')) return nested.innerText.trim();
      }
    }
    return null;
  }

  static String _clean(String raw) {
    if (raw.isEmpty) return '';
    final text = html_parser.parse(raw).documentElement?.text ?? raw;
    return text.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static Duration _parseDuration(String? value) {
    if (value == null || value.trim().isEmpty) return Duration.zero;
    final parts = value.trim().split(':').map((v) => int.tryParse(v) ?? 0).toList();
    if (parts.length == 1) return Duration(seconds: parts[0]);
    if (parts.length == 2) return Duration(minutes: parts[0], seconds: parts[1]);
    if (parts.length == 3) return Duration(hours: parts[0], minutes: parts[1], seconds: parts[2]);
    return Duration.zero;
  }

  static DateTime? _parseDate(String? value) {
    if (value == null || value.isEmpty) return null;
    final parsed = DateTime.tryParse(value);
    if (parsed != null) return parsed;
    try { return HttpDate.parse(value); } catch (_) { return null; }
  }
}
