// ─────────────────────────────────────────────
// lib/services/download_service.dart
// فعلاً placeholder: دانلود «به‌زودی» فعال می‌شود.
// ساختار آماده است: Episode.localPath اگر پر باشد از حافظهٔ محلی پخش می‌شود.
// ─────────────────────────────────────────────
import '../models/episode.dart';

class DownloadService {
  DownloadService._();
  static final DownloadService instance = DownloadService._();

  bool get isSupported => false;

  Future<bool> download(Episode episode) async => false;

  Future<String?> localPathFor(String episodeId) async => null;
}
