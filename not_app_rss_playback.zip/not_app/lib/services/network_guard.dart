// ─────────────────────────────────────────────
// lib/services/network_guard.dart
// دروازهٔ مرکزی کنترل اینترنت (سینگلتون)
//  - userEnabled: کلید کاربر (ذخیره در SharedPreferences)
//  - deviceConnected: وضعیت واقعی اتصال گوشی (connectivity_plus)
//  - allowRequest(url): قبل از هر درخواست صدا زده می‌شود و لاگ می‌کند
// ─────────────────────────────────────────────
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// وقتی درخواست توسط برنامه مسدود شده باشد.
class NetworkBlockedException implements Exception {
  final String message;
  const NetworkBlockedException(
      [this.message = 'اینترنت برنامه قطع است — ابتدا آن را روشن کنید']);
  @override
  String toString() => message;
}

class NetworkLogEntry {
  final String url;
  final DateTime time;
  final bool allowed;
  const NetworkLogEntry(this.url, this.time, this.allowed);
}

class NetworkGuard {
  NetworkGuard._();
  static final NetworkGuard instance = NetworkGuard._();

  static const _prefKey = 'userEnabled';
  static const _maxLogs = 100;

  bool userEnabled = true;
  bool deviceConnected = true;
  bool get isOnline => userEnabled && deviceConnected;

  final _statusCtrl = StreamController<bool>.broadcast();
  final _logCtrl = StreamController<List<NetworkLogEntry>>.broadcast();
  final List<NetworkLogEntry> _logs = [];
  StreamSubscription<List<ConnectivityResult>>? _connSub;

  Stream<bool> get statusStream => _statusCtrl.stream;
  Stream<List<NetworkLogEntry>> get logStream => _logCtrl.stream;
  List<NetworkLogEntry> get logs => List.unmodifiable(_logs);

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    userEnabled = prefs.getBool(_prefKey) ?? true;

    final conn = Connectivity();
    try {
      _onConnectivity(await conn.checkConnectivity());
    } catch (_) {
      deviceConnected = true;
    }
    _connSub?.cancel();
    _connSub = conn.onConnectivityChanged.listen(_onConnectivity);
  }

  void _onConnectivity(List<ConnectivityResult> results) {
    deviceConnected = results.any((r) => r != ConnectivityResult.none);
    _statusCtrl.add(isOnline);
  }

  Future<void> setUserEnabled(bool value) async {
    userEnabled = value;
    _statusCtrl.add(isOnline);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefKey, value);
  }

  /// قبل از هر درخواست صدا زده می‌شود؛ نتیجه را لاگ می‌کند.
  bool allowRequest(String url) {
    final allowed = isOnline;
    _logs.add(NetworkLogEntry(url, DateTime.now(), allowed));
    if (_logs.length > _maxLogs) _logs.removeAt(0);
    _logCtrl.add(List.unmodifiable(_logs));
    return allowed;
  }

  void clearLogs() {
    _logs.clear();
    _logCtrl.add(const []);
  }

  void dispose() {
    _connSub?.cancel();
    _statusCtrl.close();
    _logCtrl.close();
  }
}
