// ─────────────────────────────────────────────
// lib/services/audio_service.dart
// سرویس پخش صدا بر پایهٔ just_audio (+ just_audio_background برای نوتیفیکیشن).
// صف پخش (queue) برای قبلی/بعدی، و سرعت پخش.
//
// ⚠️ نکته: just_audio در اندروید با ExoPlayer (نیتیو) استریم می‌کند و
// HttpOverrides آن را نمی‌بیند؛ بنابراین قبل از شروع پخش، آدرس صدا
// صریحاً از NetworkGuard.allowRequest رد می‌شود (و لاگ می‌شود).
// ─────────────────────────────────────────────
import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

import '../models/episode.dart';
import 'network_guard.dart';

class AppAudioService {
  AppAudioService._();
  static final AppAudioService instance = AppAudioService._();

  final AudioPlayer _player = AudioPlayer();
  final List<Episode> _queue = [];
  int _index = -1;
  Episode? _current;
  final _episodeCtrl = StreamController<Episode?>.broadcast();

  Future<void> init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    // رفتن خودکار به اپیزود بعدی
    _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed) {
        next(auto: true);
      }
    });
  }

  // ───── Streams ─────
  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Episode?> get currentEpisodeStream => _episodeCtrl.stream;

  // ───── وضعیت ─────
  Episode? get current => _current;
  Duration get position => _player.position;
  Duration? get duration => _player.duration;
  double get speed => _player.speed;
  bool get playing => _player.playing;
  bool get hasNext => _index >= 0 && _index + 1 < _queue.length;
  bool get hasPrevious => _index > 0;

  // ───── کنترل ─────
  Future<void> play(Episode e,
      {List<Episode>? queue, Duration startAt = Duration.zero}) async {
    final isLocal = e.localPath != null;
    if (!isLocal && !NetworkGuard.instance.allowRequest(e.audioUrl)) {
      throw const NetworkBlockedException();
    }

    if (queue != null) {
      _queue
        ..clear()
        ..addAll(queue);
    }
    if (!_queue.any((x) => x.id == e.id)) {
      _queue
        ..clear()
        ..add(e);
    }
    _index = _queue.indexWhere((x) => x.id == e.id);
    _current = e;
    _episodeCtrl.add(e);

    try {
      final uri = isLocal ? Uri.file(e.localPath!) : Uri.parse(e.audioUrl);
      final item = MediaItem(
        id: e.id,
        title: e.title,
        album: e.podcastTitle,
        artUri: Uri.tryParse(e.imageUrl),
      );
      await _player.setAudioSource(
        AudioSource.uri(uri, tag: item),
        initialPosition: startAt > Duration.zero ? startAt : null,
      );
      unawaited(_player.play());
    } catch (err) {
      _current = null;
      _episodeCtrl.add(null);
      rethrow;
    }
  }

  Future<void> pause() => _player.pause();

  Future<void> resume() async {
    if (_player.processingState == ProcessingState.completed) {
      await _player.seek(Duration.zero);
    }
    unawaited(_player.play());
  }

  Future<void> seek(Duration d) => _player.seek(d);

  Future<void> skipForward([Duration d = const Duration(seconds: 15)]) async {
    final dur = _player.duration ?? Duration.zero;
    var target = _player.position + d;
    if (dur > Duration.zero && target > dur) target = dur;
    await _player.seek(target);
  }

  Future<void> skipBackward([Duration d = const Duration(seconds: 15)]) async {
    var target = _player.position - d;
    if (target < Duration.zero) target = Duration.zero;
    await _player.seek(target);
  }

  Future<void> setSpeed(double s) => _player.setSpeed(s);

  Future<void> next({bool auto = false}) async {
    if (!hasNext) return;
    try {
      await play(_queue[_index + 1]);
    } catch (_) {
      await _player.pause();
    }
  }

  Future<void> previous() async {
    if (_player.position > const Duration(seconds: 3) || !hasPrevious) {
      await _player.seek(Duration.zero);
      return;
    }
    try {
      await play(_queue[_index - 1]);
    } catch (_) {
      await _player.pause();
    }
  }

  Future<void> stop() async {
    await _player.stop();
    _current = null;
    _episodeCtrl.add(null);
  }
}
