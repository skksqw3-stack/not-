// ─────────────────────────────────────────────
// lib/main.dart
// نقطهٔ شروع برنامه. ترتیب مهم است:
// ۱) نصب HttpGuard (قبل از هر چیز) تا همهٔ درخواست‌ها رهگیری شوند
// ۲) راه‌اندازی NetworkGuard و StorageService
// ۳) راه‌اندازی just_audio_background برای پخش در پس‌زمینه
// ─────────────────────────────────────────────
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'app.dart';
import 'providers/favorites_provider.dart';
import 'providers/history_provider.dart';
import 'providers/player_provider.dart';
import 'services/audio_service.dart';
import 'services/http_guard.dart';
import 'services/network_guard.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // خطاهای راه‌اندازی سرویس‌های اختیاری نباید مانع نمایش رابط کاربری شوند.
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('Flutter error: ${details.exceptionAsString()}');
  };

  HttpOverrides.global = HttpGuard();

  // هر سرویس جداگانه راه‌اندازی می‌شود؛ شکست یک سرویس، کل برنامه را متوقف نمی‌کند.
  try {
    await StorageService.instance.init().timeout(const Duration(seconds: 5));
  } catch (e, st) {
    debugPrint('Storage initialization failed: $e\n$st');
  }

  try {
    await NetworkGuard.instance.init().timeout(const Duration(seconds: 4));
  } catch (e, st) {
    debugPrint('NetworkGuard initialization failed: $e\n$st');
  }

  try {
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.example.not_app.audio',
      androidNotificationChannelName: 'پخش صدا',
      androidNotificationOngoing: true,
    ).timeout(const Duration(seconds: 5));
  } catch (e, st) {
    debugPrint('Background audio initialization failed: $e\n$st');
  }

  try {
    await AppAudioService.instance.init().timeout(const Duration(seconds: 4));
  } catch (e, st) {
    debugPrint('Audio session initialization failed: $e\n$st');
  }

  timeago.setLocaleMessages('fa', timeago.FaMessages());

  // runApp حتی در صورت در دسترس نبودن اینترنت یا سرویس صوتی اجرا می‌شود.
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()),
        ChangeNotifierProvider(create: (_) => HistoryProvider()),
        ChangeNotifierProvider(
          create: (ctx) => PlayerProvider(ctx.read<HistoryProvider>()),
        ),
      ],
      child: const NotApp(),
    ),
  );
}
