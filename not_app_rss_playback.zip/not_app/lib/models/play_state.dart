// ─────────────────────────────────────────────
// lib/models/play_state.dart
// وضعیت لحظه‌ای پخش‌کننده (نگه‌داری‌شده در PlayerProvider)
// ─────────────────────────────────────────────
import 'episode.dart';

class PlayState {
  final Episode? episode;
  final bool playing;
  final bool loading;
  final double speed;

  const PlayState({
    this.episode,
    this.playing = false,
    this.loading = false,
    this.speed = 1.0,
  });

  PlayState copyWith({
    Episode? episode,
    bool clearEpisode = false,
    bool? playing,
    bool? loading,
    double? speed,
  }) =>
      PlayState(
        episode: clearEpisode ? null : (episode ?? this.episode),
        playing: playing ?? this.playing,
        loading: loading ?? this.loading,
        speed: speed ?? this.speed,
      );
}
