// مدل پادکست؛ فیدهای RSS واردشده نیز در SharedPreferences ذخیره می‌شوند.
class Podcast {
  final String id;
  final String title;
  final String author;
  final String imageUrl;
  final String feedUrl;
  final String description;
  final String category;

  const Podcast({
    required this.id,
    required this.title,
    required this.author,
    required this.imageUrl,
    required this.feedUrl,
    required this.description,
    required this.category,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'imageUrl': imageUrl,
        'feedUrl': feedUrl,
        'description': description,
        'category': category,
      };

  factory Podcast.fromJson(Map<String, dynamic> json) => Podcast(
        id: json['id'] as String,
        title: (json['title'] ?? 'پادکست بدون نام') as String,
        author: (json['author'] ?? 'ناشناس') as String,
        imageUrl: (json['imageUrl'] ?? '') as String,
        feedUrl: (json['feedUrl'] ?? '') as String,
        description: (json['description'] ?? '') as String,
        category: (json['category'] ?? 'عمومی') as String,
      );
}
