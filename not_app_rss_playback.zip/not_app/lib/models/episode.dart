// ─────────────────────────────────────────────
// lib/models/episode.dart
// مدل اپیزود + تبدیل به/از JSON (برای تاریخچه و علاقه‌مندی‌ها)
// localPath: اگر اپیزود دانلود شده باشد، از حافظهٔ محلی پخش می‌شود
// ─────────────────────────────────────────────
class Episode {
  final String id;
  final String podcastId;
  final String podcastTitle;
  final String title;
  final String description;
  final String audioUrl;
  final String imageUrl;
  final DateTime? pubDate;
  final Duration duration;
  final String? localPath;

  const Episode({
    required this.id,
    required this.podcastId,
    required this.podcastTitle,
    required this.title,
    this.description = '',
    required this.audioUrl,
    required this.imageUrl,
    this.pubDate,
    this.duration = Duration.zero,
    this.localPath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'podcastId': podcastId,
        'podcastTitle': podcastTitle,
        'title': title,
        'description': description,
        'audioUrl': audioUrl,
        'imageUrl': imageUrl,
        'pubDate': pubDate?.toIso8601String(),
        'duration': duration.inSeconds,
        'localPath': localPath,
      };

  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
        id: j['id'] as String,
        podcastId: (j['podcastId'] ?? '') as String,
        podcastTitle: (j['podcastTitle'] ?? '') as String,
        title: (j['title'] ?? '') as String,
        description: (j['description'] ?? '') as String,
        audioUrl: (j['audioUrl'] ?? '') as String,
        imageUrl: (j['imageUrl'] ?? '') as String,
        pubDate:
            j['pubDate'] == null ? null : DateTime.tryParse(j['pubDate'] as String),
        duration: Duration(seconds: (j['duration'] ?? 0) as int),
        localPath: j['localPath'] as String?,
      );
}

/// قالب‌بندی زمان: MM:SS یا H:MM:SS
String formatDuration(Duration d) {
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  final m = d.inMinutes.remainder(60);
  final s = d.inSeconds.remainder(60);
  return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
}
