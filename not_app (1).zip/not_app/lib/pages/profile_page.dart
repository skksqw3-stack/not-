// ─────────────────────────────────────────────
// lib/pages/profile_page.dart
// تب پروفایل: آواتار، آمار، تنظیمات، گزارش شبکه، درباره، اشتراک‌گذاری
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../providers/favorites_provider.dart';
import '../providers/history_provider.dart';
import 'network_log_page.dart';
import 'settings_page.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final favs = context.watch<FavoritesProvider>();
    final history = context.watch<HistoryProvider>();

    Widget stat(String value, String label) => Expanded(
          child: Column(
            children: [
              Text(value,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold, color: cs.primary)),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
            ],
          ),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Column(
              children: [
                CircleAvatar(
                  radius: 44,
                  backgroundColor: cs.primaryContainer,
                  child: Icon(Icons.person, size: 48, color: cs.onPrimaryContainer),
                ),
                const SizedBox(height: 12),
                Text('کاربر نُت',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: cs.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                stat('${favs.subscriptionCount}', 'پادکست اشتراک‌شده'),
                stat('${history.heardCount}', 'اپیزود شنیده‌شده'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('تنظیمات'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SettingsPage())),
          ),
          ListTile(
            leading: const Icon(Icons.receipt_long_outlined),
            title: const Text('گزارش شبکه'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const NetworkLogPage())),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('دربارهٔ ما'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'نُت',
              applicationVersion: '1.0.0',
              applicationLegalese: 'اپلیکیشن پادکست با کنترل کامل اینترنت',
            ),
          ),
          ListTile(
            leading: const Icon(Icons.share_outlined),
            title: const Text('اشتراک‌گذاری برنامه'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Share.share('اپلیکیشن پادکست «نُت» را امتحان کن!'),
          ),
        ],
      ),
    );
  }
}
