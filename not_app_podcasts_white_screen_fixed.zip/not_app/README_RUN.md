# نُت (not_app)

## اجرا
```bash
flutter create --org com.example --project-name not_app .   # یک‌بار: gradlew و پوشهٔ ios را می‌سازد (فایل‌های موجود را نگه دارید)
flutter pub get
flutter run
```
اگر `flutter create` فایلی را بازنویسی کرد، `lib/`، `pubspec.yaml` و `android/app/src/main/AndroidManifest.xml` را دوباره از این پروژه کپی کنید.

## انتشار
applicationId/namespace را در android/app/build.gradle عوض کنید، keystore بسازید، سپس:
`flutter build appbundle --release`


## نسخه اصلاح‌شده
- راه‌اندازی سرویس‌ها دارای timeout و مدیریت خطاست تا خطای سرویس صوتی/شبکه مانع اجرای رابط کاربری نشود.
- پادکست‌های دارای RSS معتبر از فید ناشر دریافت می‌شوند.
- برای پادکست‌هایی که هنوز فید رسمی‌شان تأیید نشده، اپیزود و صدای آزمایشی جعلی نمایش داده نمی‌شود.
- برای ساخت APK: `flutter clean` سپس `flutter pub get` و در نهایت `flutter build apk --release`.
