// ─────────────────────────────────────────────
// lib/providers/favorites_provider.dart
// علاقه‌مندی‌ها (اپیزودهای قلب‌خورده) و اشتراک‌ها (پادکست‌های دنبال‌شده)
// ─────────────────────────────────────────────
import 'package:flutter/foundation.dart';

import '../data/castbox_podcasts.dart';
import '../models/episode.dart';
import '../models/podcast.dart';
import '../services/storage_service.dart';

class FavoritesProvider extends ChangeNotifier {
  final _s = StorageService.instance;
  final Map<String, Episode> _favEpisodes = {};
  Set<String> _subs = {};

  FavoritesProvider() {
    for (final j in _s.favoriteData) {
      try {
        final e = Episode.fromJson(j);
        _favEpisodes[e.id] = e;
      } catch (_) {}
    }
    _subs = _s.subscriptions;
  }

  // ───── علاقه‌مندی‌ها ─────
  bool isFavorite(String episodeId) => _favEpisodes.containsKey(episodeId);

  List<Episode> get favoriteEpisodes => _favEpisodes.values.toList().reversed.toList();

  Future<void> toggleFavorite(Episode e) async {
    if (_favEpisodes.containsKey(e.id)) {
      _favEpisodes.remove(e.id);
    } else {
      _favEpisodes[e.id] = e;
    }
    notifyListeners();
    await _s.setFavorites(_favEpisodes.keys.toSet());
    await _s.setFavoriteData(_favEpisodes.values.map((x) => x.toJson()).toList());
  }

  // ───── اشتراک‌ها ─────
  bool isSubscribed(String podcastId) => _subs.contains(podcastId);

  List<Podcast> get subscribedPodcasts =>
      castBoxPodcasts.where((p) => _subs.contains(p.id)).toList();

  int get subscriptionCount => _subs.length;

  Future<void> toggleSubscription(String podcastId) async {
    if (!_subs.remove(podcastId)) _subs.add(podcastId);
    notifyListeners();
    await _s.setSubscriptions(_subs);
  }
}
