// ─────────────────────────────────────────────
// lib/services/rss_service.dart
// خواندن و پارس فید RSS پادکست
//  - timeout بیست ثانیه + User-Agent مناسب
//  - پاکسازی HTML توضیحات با پکیج html
//  - پارس مدت: "3600" / "01:00:00" / "60:00"
//  - اگر feedUrl خالی باشد، چند اپیزود «نمونه» برمی‌گردد تا برنامه قابل آزمایش باشد
// ─────────────────────────────────────────────
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

import '../models/episode.dart';
import '../models/podcast.dart';
import 'network_guard.dart';

class RssService {
  static const _userAgent = 'NotApp/1.0 (Flutter; Podcast Reader)';

  static Future<List<Episode>> fetchEpisodes(Podcast p) async {
    if (p.feedUrl.trim().isEmpty) {
      return <Episode>[];
    }

    try {
      final res = await http.get(Uri.parse(p.feedUrl), headers: {
        'User-Agent': _userAgent,
        'Accept': 'application/rss+xml, application/xml, text/xml, */*',
      }).timeout(const Duration(seconds: 20));

      if (res.statusCode != 200) {
        throw Exception('خطای سرور (${res.statusCode})');
      }
      final body = utf8.decode(res.bodyBytes, allowMalformed: true);
      return _parse(body, p);
    } on SocketException {
      throw const NetworkBlockedException(
          'اتصال اینترنت برقرار نیست یا توسط برنامه مسدود شده است');
    } on TimeoutException {
      throw Exception('زمان درخواست به پایان رسید');
    } on XmlException {
      throw Exception('فید نامعتبر است');
    }
  }

  // ───── پارس XML ─────
  static List<Episode> _parse(String body, Podcast p) {
    final doc = XmlDocument.parse(body);
    final channelImage = _channelImage(doc) ?? p.imageUrl;
    final episodes = <Episode>[];

    for (final item in doc.findAllElements('item')) {
      final enclosure = item.getElement('enclosure');
      final audioUrl = enclosure?.getAttribute('url');
      if (audioUrl == null || audioUrl.isEmpty) continue;

      final guid = _text(item, 'guid');
      final rawDesc = _text(item, 'description') ??
          _text(item, 'summary') ??
          _text(item, 'encoded') ??
          '';

      episodes.add(Episode(
        id: '${p.id}|${guid ?? audioUrl}',
        podcastId: p.id,
        podcastTitle: p.title,
        title: _text(item, 'title') ?? 'بدون عنوان',
        description: _clean(rawDesc),
        audioUrl: audioUrl,
        imageUrl: _itemImage(item) ?? channelImage,
        pubDate: _parseDate(_text(item, 'pubDate')),
        duration: _parseDuration(_text(item, 'duration')),
      ));
    }
    return episodes;
  }

  /// متن اولین فرزندی که نام محلی‌اش (بدون prefix) برابر [local] باشد.
  static String? _text(XmlElement e, String local) {
    for (final c in e.childElements) {
      if (c.name.local == local) {
        final t = c.innerText.trim();
        return t.isEmpty ? null : t;
      }
    }
    return null;
  }

  static String? _itemImage(XmlElement item) {
    for (final c in item.childElements) {
      if (c.name.local == 'image') {
        final href = c.getAttribute('href');
        if (href != null && href.isNotEmpty) return href;
      }
    }
    return null;
  }

  static String? _channelImage(XmlDocument doc) {
    final channel = doc.findAllElements('channel').firstOrNull;
    if (channel == null) return null;
    for (final c in channel.childElements) {
      if (c.name.local == 'image') {
        final href = c.getAttribute('href');
        if (href != null && href.isNotEmpty) return href;
        final u = c.getElement('url')?.innerText.trim();
        if (u != null && u.isNotEmpty) return u;
      }
    }
    return null;
  }

  static String _clean(String raw) {
    if (raw.isEmpty) return '';
    final text = html_parser.parse(raw).documentElement?.text ?? raw;
    return text.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static Duration _parseDuration(String? s) {
    if (s == null || s.isEmpty) return Duration.zero;
    final parts = s.split(':').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    switch (parts.length) {
      case 1:
        return Duration(seconds: parts[0]);
      case 2:
        return Duration(minutes: parts[0], seconds: parts[1]);
      case 3:
        return Duration(hours: parts[0], minutes: parts[1], seconds: parts[2]);
      default:
        return Duration.zero;
    }
  }

  static const _months = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
  };

  /// فرمت RFC-822: "Wed, 02 Oct 2024 13:00:00 +0000"
  static DateTime? _parseDate(String? s) {
    if (s == null) return null;
    final iso = DateTime.tryParse(s);
    if (iso != null) return iso;
    final m = RegExp(
            r'(\d{1,2})\s+([A-Za-z]{3})[a-z]*\s+(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?')
        .firstMatch(s);
    if (m == null) return null;
    final month = _months[m.group(2)!.toLowerCase()];
    if (month == null) return null;
    return DateTime.utc(
      int.parse(m.group(3)!),
      month,
      int.parse(m.group(1)!),
      int.parse(m.group(4)!),
      int.parse(m.group(5)!),
      int.tryParse(m.group(6) ?? '0') ?? 0,
    );
  }
}
