// ─────────────────────────────────────────────
// lib/models/podcast.dart
// مدل پادکست
// ─────────────────────────────────────────────
class Podcast {
  final String id;
  final String title;
  final String author;
  final String imageUrl;
  final String feedUrl;
  final String description;
  final String category;

  const Podcast({
    required this.id,
    required this.title,
    required this.author,
    required this.imageUrl,
    required this.feedUrl,
    required this.description,
    required this.category,
  });
}
