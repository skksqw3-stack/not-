// ─────────────────────────────────────────────
// lib/pages/home_page.dart
// تب خانه: ادامه گوش دادن، پادکست‌های محبوب، جدیدترین اپیزودها، دسته‌بندی‌ها
// Pull-to-refresh + Shimmer + نوار هشدار آفلاین
// ─────────────────────────────────────────────
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/castbox_podcasts.dart';
import '../data/categories.dart';
import '../models/episode.dart';
import '../models/podcast.dart';
import '../providers/history_provider.dart';
import '../services/network_guard.dart';
import '../services/rss_service.dart';
import '../theme/app_theme.dart';
import '../widgets/category_chip.dart';
import '../widgets/episode_tile.dart';
import '../widgets/network_switch.dart';
import '../widgets/podcast_card.dart';
import '../widgets/shimmer_loading.dart';
import 'category_page.dart';
import 'search_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Episode>> _latest;
  StreamSubscription<bool>? _sub;

  @override
  void initState() {
    super.initState();
    _latest = _loadLatest();
    // وقتی اینترنت دوباره وصل شد، خودکار بارگذاری کن
    _sub = NetworkGuard.instance.statusStream.listen((online) {
      if (online && mounted) setState(() => _latest = _loadLatest());
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<List<Episode>> _safe(Podcast p) async {
    try {
      return (await RssService.fetchEpisodes(p)).take(3).toList();
    } catch (_) {
      return <Episode>[];
    }
  }

  Future<List<Episode>> _loadLatest() async {
    final lists = await Future.wait(castBoxPodcasts.map(_safe));
    final all = lists.expand((e) => e).toList();
    all.sort((a, b) {
      final da = a.pubDate, db = b.pubDate;
      if (da == null && db == null) return 0;
      if (da == null) return 1;
      if (db == null) return -1;
      return db.compareTo(da);
    });
    return all.take(12).toList();
  }

  Future<void> _refresh() async {
    final f = _loadLatest();
    setState(() => _latest = f);
    await f;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('نُت',
            style: TextStyle(
                color: AppTheme.primary, fontWeight: FontWeight.w900, fontSize: 26)),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SearchPage())),
          ),
          const NetworkSwitch(compact: true),
          const SizedBox(width: 4),
        ],
      ),
      body: Column(
        children: [
          const OfflineBanner(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.only(bottom: 24),
                children: [
                  // ───── ادامه گوش دادن ─────
                  Consumer<HistoryProvider>(builder: (context, h, _) {
                    final items = h.inProgress;
                    if (items.isEmpty) return const SizedBox.shrink();
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const _SectionTitle('ادامه گوش دادن'),
                        SizedBox(
                          height: 92,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: items.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 12),
                            itemBuilder: (_, i) {
                              final en = items[i];
                              return InkWell(
                                borderRadius: BorderRadius.circular(16),
                                onTap: () => playEpisodeWithFeedback(
                                    context, en.episode, [en.episode]),
                                child: Container(
                                  width: 250,
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: cs.surfaceContainerHighest,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Row(
                                    children: [
                                      PodcastImage(
                                          url: en.episode.imageUrl, size: 70, radius: 10),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(en.episode.title,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    fontWeight: FontWeight.w600)),
                                            const SizedBox(height: 6),
                                            LinearProgressIndicator(
                                                value: en.progress, minHeight: 3),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    );
                  }),

                  // ───── پادکست‌های محبوب ─────
                  const _SectionTitle('پادکست‌های محبوب'),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 16,
                      crossAxisSpacing: 16,
                      childAspectRatio: .72,
                    ),
                    itemCount: castBoxPodcasts.length,
                    itemBuilder: (_, i) =>
                        PodcastCard(podcast: castBoxPodcasts[i], heroPrefix: 'home'),
                  ),

                  // ───── جدیدترین اپیزودها ─────
                  const _SectionTitle('جدیدترین اپیزودها'),
                  FutureBuilder<List<Episode>>(
                    future: _latest,
                    builder: (context, snap) {
                      if (snap.connectionState != ConnectionState.done) {
                        return const ShimmerHList();
                      }
                      final list = snap.data ?? const <Episode>[];
                      if (list.isEmpty) {
                        return Padding(
                          padding: const EdgeInsets.all(24),
                          child: Center(
                            child: Text(
                              NetworkGuard.instance.isOnline
                                  ? 'اپیزودی برای نمایش نیست'
                                  : 'برای دیدن اپیزودها اینترنت را روشن کنید',
                              style: TextStyle(color: cs.onSurfaceVariant),
                            ),
                          ),
                        );
                      }
                      return SizedBox(
                        height: 218,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (_, i) {
                            final e = list[i];
                            return InkWell(
                              borderRadius: BorderRadius.circular(16),
                              onTap: () => playEpisodeWithFeedback(context, e, list),
                              child: SizedBox(
                                width: 150,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    PodcastImage(url: e.imageUrl, size: 150, radius: 16),
                                    const SizedBox(height: 8),
                                    Text(e.title,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600, fontSize: 13)),
                                    Text(e.podcastTitle,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            fontSize: 11, color: cs.onSurfaceVariant)),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),

                  // ───── دسته‌بندی‌ها ─────
                  const _SectionTitle('دسته‌بندی‌ها'),
                  SizedBox(
                    height: 44,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: appCategories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => CategoryChip(
                        category: appCategories[i],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CategoryPage(category: appCategories[i])),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
      );
}
