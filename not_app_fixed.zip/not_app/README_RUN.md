# نُت (not_app)

## اجرا
```bash
flutter create --org com.example --project-name not_app .   # یک‌بار: gradlew و پوشهٔ ios را می‌سازد (فایل‌های موجود را نگه دارید)
flutter pub get
flutter run
```
اگر `flutter create` فایلی را بازنویسی کرد، `lib/`، `pubspec.yaml` و `android/app/src/main/AndroidManifest.xml` را دوباره از این پروژه کپی کنید.

## انتشار
applicationId/namespace را در android/app/build.gradle عوض کنید، keystore بسازید، سپس:
`flutter build appbundle --release`
