// ─────────────────────────────────────────────
// lib/main.dart
// نقطهٔ شروع برنامه. ترتیب مهم است:
// ۱) نصب HttpGuard (قبل از هر چیز) تا همهٔ درخواست‌ها رهگیری شوند
// ۲) راه‌اندازی NetworkGuard و StorageService
// ۳) راه‌اندازی just_audio_background برای پخش در پس‌زمینه
// ─────────────────────────────────────────────
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'app.dart';
import 'providers/favorites_provider.dart';
import 'providers/history_provider.dart';
import 'providers/player_provider.dart';
import 'services/audio_service.dart';
import 'services/http_guard.dart';
import 'services/network_guard.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ۱) رهگیری تمام درخواست‌های HTTP/HTTPS برنامه
  HttpOverrides.global = HttpGuard();

  // ۲) سرویس‌های پایه
  await StorageService.instance.init();
  await NetworkGuard.instance.init();

  // ۳) پخش پس‌زمینه + نوتیفیکیشن
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.example.not_app.audio',
    androidNotificationChannelName: 'پخش صدا',
    androidNotificationOngoing: true,
  );
  await AppAudioService.instance.init();

  timeago.setLocaleMessages('fa', timeago.FaMessages());

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()),
        ChangeNotifierProvider(create: (_) => HistoryProvider()),
        ChangeNotifierProvider(
          create: (ctx) => PlayerProvider(ctx.read<HistoryProvider>()),
        ),
      ],
      child: const NotApp(),
    ),
  );
}
