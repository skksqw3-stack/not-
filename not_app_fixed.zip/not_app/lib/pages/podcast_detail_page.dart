// ─────────────────────────────────────────────
// lib/pages/podcast_detail_page.dart
// جزئیات پادکست: SliverAppBar با تصویر blur، اطلاعات و لیست اپیزودها
// ─────────────────────────────────────────────
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/episode.dart';
import '../models/podcast.dart';
import '../providers/favorites_provider.dart';
import '../services/rss_service.dart';
import '../widgets/empty_state.dart';
import '../widgets/episode_tile.dart';
import '../widgets/podcast_card.dart';
import '../widgets/shimmer_loading.dart';
import 'mini_player.dart';

class PodcastDetailPage extends StatefulWidget {
  final Podcast podcast;
  final String heroTag;

  const PodcastDetailPage({super.key, required this.podcast, required this.heroTag});

  @override
  State<PodcastDetailPage> createState() => _PodcastDetailPageState();
}

class _PodcastDetailPageState extends State<PodcastDetailPage> {
  late Future<List<Episode>> _future;

  @override
  void initState() {
    super.initState();
    _future = RssService.fetchEpisodes(widget.podcast);
  }

  void _retry() => setState(() => _future = RssService.fetchEpisodes(widget.podcast));

  @override
  Widget build(BuildContext context) {
    final p = widget.podcast;
    final cs = Theme.of(context).colorScheme;
    final favs = context.watch<FavoritesProvider>();
    final subscribed = favs.isSubscribed(p.id);

    return Scaffold(
      bottomNavigationBar: const MiniPlayer(),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 320,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  ImageFiltered(
                    imageFilter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
                    child: PodcastImage(url: p.imageUrl, radius: 0),
                  ),
                  Container(color: Colors.black38),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Hero(
                        tag: widget.heroTag,
                        child: PodcastImage(url: p.imageUrl, size: 190, radius: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.title,
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(p.author, style: TextStyle(color: cs.onSurfaceVariant)),
                  const SizedBox(height: 8),
                  Chip(label: Text(p.category)),
                  const SizedBox(height: 8),
                  Text(p.description, maxLines: 6, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      subscribed
                          ? OutlinedButton.icon(
                              icon: const Icon(Icons.check),
                              label: const Text('دنبال می‌کنید'),
                              onPressed: () => favs.toggleSubscription(p.id),
                            )
                          : FilledButton.icon(
                              icon: const Icon(Icons.add),
                              label: const Text('اشتراک'),
                              onPressed: () => favs.toggleSubscription(p.id),
                            ),
                      FilledButton.tonalIcon(
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('پخش آخرین اپیزود'),
                        onPressed: () async {
                          try {
                            final eps = await _future;
                            if (eps.isNotEmpty && context.mounted) {
                              playEpisodeWithFeedback(context, eps.first, eps);
                            }
                          } catch (_) {}
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          FutureBuilder<List<Episode>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const SliverToBoxAdapter(child: ShimmerList());
              }
              if (snap.hasError) {
                return SliverToBoxAdapter(
                  child: SizedBox(
                    height: 280,
                    child: EmptyState(
                      icon: Icons.error_outline,
                      title: 'دریافت اپیزودها ناموفق بود',
                      message: snap.error.toString().replaceFirst('Exception: ', ''),
                      actionLabel: 'تلاش دوباره',
                      onAction: _retry,
                    ),
                  ),
                );
              }
              final eps = snap.data ?? const <Episode>[];
              if (eps.isEmpty) {
                return const SliverToBoxAdapter(
                  child: SizedBox(
                    height: 280,
                    child: EmptyState(
                      icon: Icons.podcasts,
                      title: 'اپیزودی وجود ندارد',
                    ),
                  ),
                );
              }
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) => EpisodeTile(episode: eps[i], queue: eps),
                  childCount: eps.length,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
