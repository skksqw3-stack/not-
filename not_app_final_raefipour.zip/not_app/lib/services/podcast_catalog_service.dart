// جست‌وجوی پویا در کاتالوگ عمومی Apple Podcasts و بازگرداندن فقط فیدهای RSS.
// این سرویس از API عمومی Search استفاده می‌کند و به کل کاتالوگ اختصاصی Castbox دسترسی ندارد.
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/podcast.dart';
import 'network_guard.dart';

class PodcastCatalogService {
  PodcastCatalogService._();
  static final PodcastCatalogService instance = PodcastCatalogService._();

  Future<List<Podcast>> search(String term) async {
    final query = term.trim();
    if (query.isEmpty) return <Podcast>[];

    final markets = <String>['us', 'gb', 'ca', 'au'];
    final terms = _searchTerms(query);
    Object? lastError;
    var successfulRequests = 0;
    final requests = <Future<List<Podcast>>>[];
    for (final term in terms) {
      for (final market in markets) {
        requests.add(_searchMarket(term, market).then((batch) {
          successfulRequests++;
          return batch;
        }).catchError((Object error) {
          lastError = error;
          return <Podcast>[];
        }));
      }
    }
    final results = await Future.wait(requests);
    if (successfulRequests == 0 && lastError != null) {
      throw lastError;
    }
    final byFeed = <String, Podcast>{};
    for (final batch in results) {
      for (final podcast in batch) {
        byFeed.putIfAbsent(podcast.feedUrl.toLowerCase(), () => podcast);
      }
    }
    return byFeed.values.toList()
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
  }

  List<String> _searchTerms(String query) {
    final normalized = query
        .replaceAll('ي', 'ی')
        .replaceAll('ك', 'ک')
        .replaceAll('‌', ' ')
        .toLowerCase();
    final isRaefipour = normalized.contains('رائفی') ||
        normalized.contains('رایفی') ||
        normalized.contains('raefipour') ||
        normalized.contains('masaf');
    if (!isRaefipour) return <String>[query];

    // Castbox channel names use several spellings. Search these aliases in
    // the public Apple Podcasts catalogue; only results with a real feedUrl
    // are returned. We intentionally do not invent a Castbox RSS URL.
    return <String>[
      query,
      'رائفی پور',
      'رائفی‌پور',
      'علی اکبر رائفی پور',
      'Raefipour',
      'Masaf',
    ].toSet().toList();
  }

  Future<List<Podcast>> _searchMarket(String term, String country) async {
    final uri = Uri.https('itunes.apple.com', '/search', {
      'term': term,
      'media': 'podcast',
      'entity': 'podcast',
      'country': country,
      'limit': '200',
      'explicit': 'Yes',
    });
    if (!NetworkGuard.instance.allowRequest(uri.toString())) {
      throw const NetworkBlockedException('دسترسی اینترنت در تنظیمات برنامه غیرفعال است.');
    }

    final response = await http.get(uri, headers: {
      'Accept': 'application/json',
      'User-Agent': 'NotApp/1.2 (Podcast RSS Search)',
    }).timeout(const Duration(seconds: 18));
    if (response.statusCode != 200) {
      throw Exception('جست‌وجوی کاتالوگ در بازار $country ناموفق بود (${response.statusCode}).');
    }

    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic>) return <Podcast>[];
    final rows = decoded['results'];
    if (rows is! List) return <Podcast>[];

    final podcasts = <Podcast>[];
    for (final row in rows) {
      if (row is! Map) continue;
      final feed = (row['feedUrl'] ?? '').toString().trim();
      final title = (row['collectionName'] ?? '').toString().trim();
      if (feed.isEmpty || title.isEmpty) continue;
      final parsed = Uri.tryParse(feed);
      if (parsed == null || !{'http', 'https'}.contains(parsed.scheme)) continue;
      final artwork = (row['artworkUrl600'] ?? row['artworkUrl100'] ?? '').toString();
      final author = (row['artistName'] ?? 'ناشناس').toString();
      final genre = (row['primaryGenreName'] ?? 'عمومی').toString();
      final description = (row['collectionName'] ?? title).toString();
      podcasts.add(Podcast(
        id: 'itunes_${row['collectionId'] ?? feed.hashCode}',
        title: title,
        author: author,
        imageUrl: artwork,
        feedUrl: feed,
        description: description,
        category: genre,
      ));
    }
    return podcasts;
  }
}
