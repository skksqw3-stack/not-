// ─────────────────────────────────────────────
// lib/pages/discover_page.dart
// تب کشف: جستجو، دسته‌بندی‌های محبوب، پیشنهادها، Top charts
// ─────────────────────────────────────────────
import 'package:flutter/material.dart';

import '../data/castbox_podcasts.dart';
import '../data/categories.dart';
import '../widgets/podcast_card.dart';
import 'category_page.dart';
import 'search_page.dart';
import 'rss_library_page.dart';

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final suggested = castBoxPodcasts.reversed.take(6).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('کشف')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          // افزودن فید RSS شخصی
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: FilledButton.tonalIcon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RssLibraryPage()),
              ),
              icon: const Icon(Icons.rss_feed),
              label: const Text('افزودن پادکست با لینک RSS و پخش داخل نُت'),
            ),
          ),

          // نوار جستجو
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: InkWell(
              borderRadius: BorderRadius.circular(28),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const SearchPage())),
              child: Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Row(
                  children: [
                    Icon(Icons.search, color: cs.onSurfaceVariant),
                    const SizedBox(width: 12),
                    Text('جستجوی پادکست یا نویسنده',
                        style: TextStyle(color: cs.onSurfaceVariant)),
                  ],
                ),
              ),
            ),
          ),

          const _Title('جست‌وجوی سریع پادکست‌ها'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _QuickSearchChip(
                  label: 'رائفی‌پور و مصاف',
                  query: 'رائفی پور',
                ),
                _QuickSearchChip(label: 'چنل‌بی', query: 'چنل بی'),
                _QuickSearchChip(label: 'بی‌پلاس', query: 'بی پلاس'),
                _QuickSearchChip(label: 'پادکست‌های فارسی', query: 'پادکست فارسی'),
              ],
            ),
          ),

          const _Title('دسته‌بندی‌های محبوب'),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 12,
              crossAxisSpacing: 8,
              childAspectRatio: .85,
            ),
            itemCount: appCategories.length,
            itemBuilder: (_, i) {
              final c = appCategories[i];
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => CategoryPage(category: c))),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: cs.primaryContainer,
                      child: Icon(c.icon, color: cs.onPrimaryContainer),
                    ),
                    const SizedBox(height: 6),
                    Text(c.name, style: const TextStyle(fontSize: 12)),
                  ],
                ),
              );
            },
          ),

          const _Title('پادکست‌های پیشنهادی'),
          SizedBox(
            height: 215,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: suggested.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => SizedBox(
                width: 140,
                child: PodcastCard(podcast: suggested[i], heroPrefix: 'discover'),
              ),
            ),
          ),

          const _Title('Top Charts'),
          for (var i = 0; i < castBoxPodcasts.length; i++)
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 28,
                    child: Text('${i + 1}',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: i < 3 ? cs.primary : cs.onSurfaceVariant)),
                  ),
                  const SizedBox(width: 8),
                  PodcastImage(url: castBoxPodcasts[i].imageUrl, size: 48, radius: 10),
                ],
              ),
              title: Text(castBoxPodcasts[i].title),
              subtitle: Text('${castBoxPodcasts[i].author} • ${castBoxPodcasts[i].category}'),
              onTap: () => openPodcast(context, castBoxPodcasts[i], 'chart'),
            ),
        ],
      ),
    );
  }
}

class _QuickSearchChip extends StatelessWidget {
  final String label;
  final String query;
  const _QuickSearchChip({required this.label, required this.query});

  @override
  Widget build(BuildContext context) => ActionChip(
        avatar: const Icon(Icons.search, size: 17),
        label: Text(label),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => SearchPage(initialQuery: query)),
        ),
      );
}

class _Title extends StatelessWidget {
  final String text;
  const _Title(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
      );
}
