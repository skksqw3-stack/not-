// جست‌وجوی محلی و پویا در کاتالوگ عمومی پادکست‌ها؛ فقط نتایج دارای RSS نمایش داده می‌شوند.
import 'dart:async';

import 'package:flutter/material.dart';

import '../data/castbox_podcasts.dart';
import '../models/podcast.dart';
import '../services/podcast_catalog_service.dart';
import '../services/storage_service.dart';
import '../widgets/empty_state.dart';
import '../widgets/podcast_card.dart';

class SearchPage extends StatefulWidget {
  final String initialQuery;
  const SearchPage({super.key, this.initialQuery = ''});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _controller = TextEditingController();
  final _storage = StorageService.instance;
  Timer? _debounce;
  late List<String> _history;
  late List<Podcast> _customPodcasts;
  String _query = '';
  List<Podcast> _remoteResults = <Podcast>[];
  bool _loading = false;
  String? _error;
  int _requestNumber = 0;

  @override
  void initState() {
    super.initState();
    _history = _storage.searchHistory;
    _query = widget.initialQuery;
    _controller.text = widget.initialQuery;
    _customPodcasts = _storage.customPodcasts
        .map((json) {
          try { return Podcast.fromJson(json); } catch (_) { return null; }
        })
        .whereType<Podcast>()
        .toList();
    if (widget.initialQuery.trim().length >= 2) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _searchRemote(widget.initialQuery);
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  String _norm(String s) => s
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('\u200c', ' ')
      .toLowerCase()
      .trim();

  void _onQueryChanged(String value) {
    setState(() {
      _query = value;
      _error = null;
      _remoteResults = <Podcast>[];
    });
    _debounce?.cancel();
    if (value.trim().length < 2) {
      setState(() => _loading = false);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 550), () => _searchRemote(value));
  }

  Future<void> _searchRemote(String value) async {
    final q = value.trim();
    if (q.length < 2) return;
    final request = ++_requestNumber;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await PodcastCatalogService.instance.search(q);
      if (!mounted || request != _requestNumber) return;
      setState(() {
        _remoteResults = results;
        _loading = false;
      });
    } catch (e) {
      if (!mounted || request != _requestNumber) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  void _submit(String q) {
    final t = q.trim();
    if (t.isEmpty) return;
    _history
      ..remove(t)
      ..insert(0, t);
    if (_history.length > 10) _history = _history.sublist(0, 10);
    _storage.setSearchHistory(_history);
    _searchRemote(t);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final q = _norm(_query);
    final localResults = q.isEmpty
        ? <Podcast>[]
        : [...castBoxPodcasts, ..._customPodcasts]
            .where((p) => p.feedUrl.isNotEmpty &&
                (_norm(p.title).contains(q) || _norm(p.author).contains(q)))
            .toList();
    final combined = <String, Podcast>{};
    for (final p in [...localResults, ..._remoteResults]) {
      combined.putIfAbsent(p.feedUrl.toLowerCase(), () => p);
    }
    final results = combined.values.toList();

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
            hintText: 'جستجوی پادکست یا نویسنده در کاتالوگ جهانی',
            border: InputBorder.none,
          ),
          onChanged: _onQueryChanged,
          onSubmitted: _submit,
        ),
        actions: [
          if (_query.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                _debounce?.cancel();
                _controller.clear();
                setState(() {
                  _query = '';
                  _remoteResults = <Podcast>[];
                  _loading = false;
                  _error = null;
                });
              },
            ),
        ],
      ),
      body: q.isEmpty ? _buildHistory() : _buildResults(results),
    );
  }

  Widget _buildResults(List<Podcast> results) {
    if (_loading && results.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && results.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, size: 42),
            const SizedBox(height: 12),
            Text(_error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => _searchRemote(_query),
              icon: const Icon(Icons.refresh),
              label: const Text('تلاش دوباره'),
            ),
          ]),
        ),
      );
    }
    if (results.isEmpty) {
      return const EmptyState(
        icon: Icons.search_off,
        title: 'پادکستی پیدا نشد',
        message: 'عبارت دیگری را امتحان کنید. فقط پادکست‌های دارای RSS عمومی نمایش داده می‌شوند.',
      );
    }
    return Column(children: [
      if (_loading) const LinearProgressIndicator(minHeight: 2),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Align(
          alignment: Alignment.centerRight,
          child: Text('${results.length} نتیجه دارای RSS',
              style: Theme.of(context).textTheme.labelMedium),
        ),
      ),
      Expanded(
        child: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: .72,
          ),
          itemCount: results.length,
          itemBuilder: (_, i) => PodcastCard(podcast: results[i], heroPrefix: 'search'),
        ),
      ),
    ]);
  }

  Widget _buildHistory() {
    if (_history.isEmpty) {
      return const EmptyState(
        icon: Icons.travel_explore,
        title: 'جست‌وجوی پادکست‌ها',
        message: 'نام پادکست، موضوع یا سازنده را بنویس. نُت در کاتالوگ عمومی جست‌وجو می‌کند و فیدهای RSS را نمایش می‌دهد.',
      );
    }
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
          child: Row(children: [
            const Expanded(child: Text('جستجوهای اخیر', style: TextStyle(fontWeight: FontWeight.bold))),
            TextButton(
              onPressed: () {
                setState(() => _history = []);
                _storage.setSearchHistory([]);
              },
              child: const Text('پاک کردن'),
            ),
          ]),
        ),
        for (final h in _history)
          ListTile(
            leading: const Icon(Icons.history),
            title: Text(h),
            trailing: IconButton(
              icon: const Icon(Icons.close, size: 18),
              onPressed: () {
                setState(() => _history.remove(h));
                _storage.setSearchHistory(_history);
              },
            ),
            onTap: () {
              _controller.text = h;
              _controller.selection = TextSelection.collapsed(offset: h.length);
              _onQueryChanged(h);
              _submit(h);
            },
          ),
      ],
    );
  }
}
