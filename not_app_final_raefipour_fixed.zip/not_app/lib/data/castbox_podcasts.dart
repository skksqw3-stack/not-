// فهرست پادکست‌های فارسی نُت. فقط آدرس‌هایی که از ناشر/فهرست معتبر
// پیدا شده‌اند در feedUrl قرار گرفته‌اند؛ موارد بدون فید به‌صورت نمونه پخش نمی‌شوند.
import '../models/podcast.dart';

const List<Podcast> castBoxPodcasts = [
  Podcast(
    id: 'p1', title: 'رادیو مرز', author: 'تیم رادیو مرز',
    imageUrl: 'https://picsum.photos/seed/radiomarz/300',
    feedUrl: 'https://feeds.acast.com/public/shows/65674fccc3ca8a00127b7474',
    description: 'روایت آدم‌ها از فاصله‌ای که با دیگران احساس می‌کنند.', category: 'مستند',
  ),
  Podcast(
    id: 'p2', title: 'چنل‌بی', author: 'علی بندری و تیم چنل‌بی',
    imageUrl: 'https://picsum.photos/seed/channelb/300',
    feedUrl: 'https://feeds.acast.com/public/shows/channelbpodcast',
    description: 'روایت ماجراهای واقعی و داستان‌های مستند.', category: 'مستند',
  ),
  Podcast(
    id: 'p3', title: 'پادکست رخ', author: 'امیر سودبخش',
    imageUrl: 'https://picsum.photos/seed/rokh/300',
    feedUrl: 'https://feeds.acast.com/public/shows/65e095ffbec0f30016047f7e',
    description: 'داستان زندگی کسانی که قسمتی از تاریخ ایران و جهان را رقم زدند.', category: 'تاریخ',
  ),
  Podcast(
    id: 'p4', title: 'بی‌پلاس', author: 'علی بندری',
    imageUrl: 'https://picsum.photos/seed/bplus/300',
    feedUrl: 'https://feeds.acast.com/public/shows/65417dfc6143f1001280fb90',
    description: 'خلاصه و روایت کتاب‌های غیرداستانی.', category: 'کتاب',
  ),
  Podcast(
    id: 'p5', title: 'دغدغه ایران', author: 'محمد فاضلی',
    imageUrl: 'https://picsum.photos/seed/daghdagheh/300',
    feedUrl: 'https://www.spreaker.com/show/7164105/episodes/feed',
    description: 'اندیشه توسعه، مسائل ایران و گفت‌وگو با اندیشمندان.', category: 'اجتماعی',
  ),
  Podcast(
    id: 'p7', title: 'رواق', author: 'فرزین رنجبر',
    imageUrl: 'https://picsum.photos/seed/ravaq/300',
    feedUrl: 'https://feeds.redcircle.com/cd4c375c-2a1d-4041-a5d2-3d817b216cd4',
    description: 'پادکستی با رویکرد روان‌شناختی و اگزیستانسیال.', category: 'فلسفه',
  ),
  Podcast(
    id: 'p9', title: 'نیک و قصه‌های شبانه', author: 'نیک و قصه‌های شبانه',
    imageUrl: 'https://picsum.photos/seed/shab/300',
    feedUrl: 'https://anchor.fm/s/10e034e04/podcast/rss',
    description: 'قصه‌های آرام فارسی برای کودکان پیش از خواب.', category: 'کودک',
  ),
];
